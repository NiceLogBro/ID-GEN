import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import { CardSvg } from "./card/CardSvg";
import type { CardInput } from "./card/model";
import { LAYOUT_META, type CardStyle } from "../lib/styles";

interface Props {
  base: Omit<CardInput, "style">;
  styles: CardStyle[];
  index: number;
  seed: number;
  onPick: (i: number) => void;
  onRefresh: () => void;
  onPrev: () => void;
  onOriginals: () => void;
}

/** Four live-rendered card styles + a "refresh for more" button that generates a new set. */
export function StylePicker({ base, styles, index, seed, onPick, onRefresh, onPrev, onOriginals }: Props) {
  const portrait = base.portrait;
  const scale = portrait ? 0.3 : 0.28;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2.5">
        {styles.map((s, i) => {
          const on = i === index;
          const meta = LAYOUT_META[s.layout];
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => onPick(i)}
              aria-pressed={on}
              aria-label={`${meta.name} style, ${s.palette.name}`}
              className={cn(
                "group relative rounded-xl border p-2.5 text-left transition-all",
                on
                  ? "border-ember-500/80 bg-ember-500/10 shadow-[0_0_0_3px_rgba(249,123,22,0.12)]"
                  : "border-ink-700 bg-ink-850 hover:border-ink-500"
              )}
            >
              <span
                className={cn(
                  "pointer-events-none flex items-center justify-center rounded-lg bg-ink-950/60",
                  portrait ? "h-[176px]" : "h-[112px]"
                )}
              >
                <CardSvg model={{ ...base, style: s }} scale={scale} className="drop-shadow-[0_6px_10px_rgba(0,0,0,0.45)]" />
              </span>
              <span className="mt-2 flex items-center justify-between gap-1">
                <span className="min-w-0">
                  <span className="block truncate text-xs font-bold text-ink-100">{meta.name}</span>
                  <span className="block truncate text-[10px] text-ink-500">{s.palette.name}</span>
                </span>
                {on && (
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-ember-500 text-ink-950">
                    <Icon name="check" className="h-3 w-3" strokeWidth={3.2} />
                  </span>
                )}
              </span>
            </button>
          );
        })}
      </div>

      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onPrev}
          disabled={seed === 0}
          aria-label="Previous style set"
          title="Previous set"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-ink-700 bg-ink-850 text-ink-300 transition-colors hover:border-ink-500 hover:text-ink-50 disabled:cursor-not-allowed disabled:opacity-35 disabled:hover:border-ink-700 disabled:hover:text-ink-300"
        >
          <Icon name="back" className="h-4 w-4" strokeWidth={2.2} />
        </button>
        <button
          type="button"
          onClick={onRefresh}
          className="flex h-10 flex-1 items-center justify-center gap-2 rounded-lg bg-ember-500 text-[13px] font-bold text-ink-950 transition-colors hover:bg-ember-400"
        >
          <span key={seed} className={cn("flex", seed > 0 && "spin-once")}>
            <Icon name="refresh" className="h-4 w-4" strokeWidth={2.3} />
          </span>
          Refresh for more styles
        </button>
      </div>

      <div className="flex items-center justify-between text-[11px] text-ink-500">
        <span>
          Set {seed + 1} · {seed === 0 ? "hand-tuned originals" : "freshly generated"}
        </span>
        {seed > 0 && (
          <button type="button" onClick={onOriginals} className="font-semibold text-ink-300 underline-offset-2 hover:text-ember-400 hover:underline">
            Back to originals
          </button>
        )}
      </div>
    </div>
  );
}
