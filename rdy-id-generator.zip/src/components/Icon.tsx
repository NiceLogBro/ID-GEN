interface IconProps {
  name: IconName;
  className?: string;
  strokeWidth?: number;
}

export type IconName =
  | "logo"
  | "download"
  | "copy"
  | "dice"
  | "reset"
  | "zoom-in"
  | "zoom-out"
  | "check"
  | "close"
  | "camera"
  | "user"
  | "portrait"
  | "landscape"
  | "badge"
  | "sparkle"
  | "search"
  | "chevron"
  | "refresh"
  | "upload"
  | "back"
  | "palette"
  | "building";

const PATHS: Record<IconName, React.ReactNode> = {
  logo: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="3" />
      <circle cx="8.5" cy="11" r="1.8" />
      <path d="M6 15.5c.5-1.4 1.4-2 2.5-2s2 .6 2.5 2" />
      <path d="M14 9.5h5" />
      <path d="M14 12.5h5" />
      <path d="M14 15.5h3" />
    </>
  ),
  badge: (
    <>
      <rect x="4" y="3" width="16" height="18" rx="3" />
      <circle cx="12" cy="9" r="2.2" />
      <path d="M8.5 14.5c.8-1.6 2-2.3 3.5-2.3s2.7.7 3.5 2.3" />
      <path d="M8 18h8" />
    </>
  ),
  download: (
    <>
      <path d="M12 3v11" />
      <path d="m7.5 10.5 4.5 4 4.5-4" />
      <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
    </>
  ),
  copy: (
    <>
      <rect x="9" y="9" width="11" height="11" rx="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </>
  ),
  dice: (
    <>
      <rect x="3.5" y="3.5" width="17" height="17" rx="3.5" />
      <circle cx="8.5" cy="8.5" r="1" fill="currentColor" stroke="none" />
      <circle cx="15.5" cy="8.5" r="1" fill="currentColor" stroke="none" />
      <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
      <circle cx="8.5" cy="15.5" r="1" fill="currentColor" stroke="none" />
      <circle cx="15.5" cy="15.5" r="1" fill="currentColor" stroke="none" />
    </>
  ),
  reset: (
    <>
      <path d="M3 12a9 9 0 1 0 3-6.7" />
      <path d="M3 4v4h4" />
    </>
  ),
  "zoom-in": (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-4.3-4.3" />
      <path d="M8 11h6" />
      <path d="M11 8v6" />
    </>
  ),
  "zoom-out": (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-4.3-4.3" />
      <path d="M8 11h6" />
    </>
  ),
  check: <path d="m4.5 12.5 5 5 10-11" />,
  close: (
    <>
      <path d="m6 6 12 12" />
      <path d="M18 6 6 18" />
    </>
  ),
  camera: (
    <>
      <path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1Z" />
      <circle cx="12" cy="13.5" r="3.5" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4.5 20.5c1.6-3.4 4.2-5 7.5-5s5.9 1.6 7.5 5" />
    </>
  ),
  portrait: (
    <>
      <rect x="6" y="3" width="12" height="18" rx="2.5" />
      <path d="M10 17h4" />
    </>
  ),
  landscape: (
    <>
      <rect x="3" y="6" width="18" height="12" rx="2.5" />
      <path d="M7 14h4" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-4.3-4.3" />
    </>
  ),
  chevron: <path d="m6 9 6 6 6-6" />,
  refresh: (
    <>
      <path d="M20 11a8 8 0 0 0-14.5-4.2L3 9.5" />
      <path d="M3 4v5.5h5.5" />
      <path d="M4 13a8 8 0 0 0 14.5 4.2L21 14.5" />
      <path d="M21 20v-5.5h-5.5" />
    </>
  ),
  upload: (
    <>
      <path d="M12 16V4" />
      <path d="m7.5 8.5 4.5-4.5 4.5 4.5" />
      <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
    </>
  ),
  back: <path d="m15 6-6 6 6 6" />,
  palette: (
    <>
      <path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.7-.8 1.7-1.6 0-.5-.2-.9-.5-1.3-.3-.4-.5-.8-.5-1.3 0-.9.7-1.6 1.6-1.6H16a5 5 0 0 0 5-5c0-3.9-4-7.2-9-7.2Z" />
      <circle cx="7.5" cy="11" r="1" fill="currentColor" stroke="none" />
      <circle cx="10.5" cy="7" r="1" fill="currentColor" stroke="none" />
      <circle cx="15.5" cy="7.5" r="1" fill="currentColor" stroke="none" />
    </>
  ),
  building: (
    <>
      <path d="M3 21h18" />
      <path d="M5 21V10l7-5 7 5v11" />
      <path d="M9 21v-6h6v6" />
      <path d="M12 10.5v0" />
    </>
  ),
  sparkle: (
    <>
      <path d="M12 3v0c.6 4.5 2.5 6.4 7 7-4.5.6-6.4 2.5-7 7-.6-4.5-2.5-6.4-7-7 4.5-.6 6.4-2.5 7-7Z" />
      <path d="M19 15.5c.3 2 1 2.8 3 3-2 .3-2.7 1-3 3-.3-2-1-2.7-3-3 2-.2 2.7-1 3-3Z" />
    </>
  ),
};

export function Icon({ name, className = "h-4 w-4", strokeWidth = 1.8 }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {PATHS[name]}
    </svg>
  );
}
