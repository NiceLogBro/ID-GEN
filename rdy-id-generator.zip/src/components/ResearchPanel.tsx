import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import { INDUSTRY_NAME } from "../lib/industries";
import { formatEmployees } from "../lib/companies";
import { orgInitials } from "../lib/logoStudio";
import type { Candidate, ResearchStep, ResearchedOrg } from "../lib/research";
import type { ResearchState } from "../lib/useResearch";

interface Props {
  state: ResearchState;
  onRun: (query: string) => void;
  onPickAlternative: (c: Candidate) => void;
  recent: ResearchedOrg[];
  activeId: string;
  onPickRecent: (id: string) => void;
  onClear: () => void;
  initialQuery: string;
}

function StepIcon({ status }: { status: ResearchStep["status"] }) {
  if (status === "run")
    return <span className="mt-[3px] h-3.5 w-3.5 shrink-0 animate-spin rounded-full border-2 border-ink-600 border-t-ember-400" />;
  if (status === "ok")
    return (
      <span className="mt-[3px] flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
        <Icon name="check" className="h-2.5 w-2.5" strokeWidth={3.5} />
      </span>
    );
  if (status === "warn")
    return (
      <span className="mt-[3px] flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-[9px] font-black text-amber-400">
        !
      </span>
    );
  return (
    <span className="mt-[3px] flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full bg-red-500/20 text-red-400">
      <Icon name="close" className="h-2.5 w-2.5" strokeWidth={3.5} />
    </span>
  );
}

function Ext() {
  return (
    <svg viewBox="0 0 12 12" className="ml-0.5 inline h-2.5 w-2.5 align-[-1px]" fill="none" stroke="currentColor" strokeWidth={1.6} aria-hidden="true">
      <path d="M4.5 2.5h5v5M9.5 2.5 3 9" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function hostOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

function LogoBox({ r, size }: { r: ResearchedOrg; size: "sm" | "lg" }) {
  const box = size === "lg" ? "h-14 w-14" : "h-5 w-5";
  if (r.logoData)
    return (
      <img
        src={r.logoData}
        alt=""
        className={cn(box, "shrink-0 rounded-lg object-contain", r.logoDark ? "bg-ink-900" : "bg-white", size === "lg" ? "p-1.5" : "p-0.5")}
      />
    );
  return (
    <span
      className={cn(box, "flex shrink-0 items-center justify-center rounded-lg bg-ink-700 font-bold text-ink-200", size === "lg" ? "text-base" : "text-[8px]")}
    >
      {orgInitials(r.name)}
    </span>
  );
}

/** "Research any company" — finds the real name, facts and official logo; hands off to the logo studio if there's none. */
export function ResearchPanel(p: Props) {
  const [q, setQ] = useState(p.initialQuery);
  const running = p.state.status === "running";
  const r = p.state.result;

  // mirror researches started elsewhere (directory dropdown, name field) in the search box
  useEffect(() => {
    if (p.state.status === "running" && p.state.query) setQ(p.state.query);
  }, [p.state.status, p.state.query]);

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (q.trim() && !running) p.onRun(q.trim());
  };

  return (
    <div className="space-y-3 rounded-xl border border-ember-500/25 bg-gradient-to-b from-ember-500/[0.07] to-transparent p-3">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-xs font-bold text-ink-100">
          <Icon name="sparkle" className="h-3.5 w-3.5 text-ember-400" strokeWidth={2} />
          Research assistant
        </span>
        <span className="text-[10px] text-ink-500">Wikidata · Wikipedia · Commons</span>
      </div>

      <form onSubmit={submit} className="flex gap-2">
        <div className="relative min-w-0 flex-1">
          <Icon name="search" className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Any company, e.g. “Patagonia”"
            aria-label="Company to research"
            className="h-10 w-full rounded-lg border border-ink-700 bg-ink-900 pl-8 pr-2 text-sm text-ink-100 outline-none placeholder:text-ink-500 focus:border-ember-500/70"
          />
        </div>
        <button
          type="submit"
          disabled={running || !q.trim()}
          className="flex h-10 shrink-0 items-center gap-1.5 rounded-lg bg-ember-500 px-3 text-[13px] font-bold text-ink-950 transition-colors hover:bg-ember-400 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {running ? (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-ink-950/40 border-t-ink-950" />
          ) : (
            <Icon name="sparkle" className="h-4 w-4" strokeWidth={2.2} />
          )}
          {running ? "Researching" : "Research"}
        </button>
      </form>

      {p.state.status === "idle" && (
        <p className="text-[11px] leading-snug text-ink-500">
          Finds the company’s real name, facts and official logo. Vague descriptions work too — try “the coffee chain from
          Seattle”. If no logo exists, the AI logo studio designs one.
        </p>
      )}

      {p.state.steps.length > 0 && (
        <ol className="space-y-1.5 rounded-lg border border-ink-800 bg-ink-950/50 p-2.5" aria-live="polite">
          {p.state.steps.map((s, i) => (
            <li key={`${s.key}-${i}`} className="fade-up flex gap-2">
              <StepIcon status={s.status} />
              <span className="min-w-0">
                <span className={cn("block text-[12px] font-semibold", s.status === "fail" ? "text-red-300" : "text-ink-100")}>{s.label}</span>
                {s.detail && <span className="block truncate text-[11px] text-ink-400" title={s.detail}>{s.detail}</span>}
              </span>
            </li>
          ))}
        </ol>
      )}

      {p.state.status === "error" && <p className="text-[11px] text-red-300">{p.state.error}</p>}

      {r && p.state.status === "done" && (
        <div className="fade-up space-y-2.5 rounded-lg border border-ink-700 bg-ink-850 p-3">
          <div className="flex gap-3">
            <LogoBox r={r} size="lg" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="truncate text-sm font-bold text-ink-50">{r.name}</span>
                <span
                  className={cn(
                    "rounded px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide",
                    r.logoData ? "bg-emerald-500/15 text-emerald-400" : "bg-ember-500/15 text-ember-400"
                  )}
                >
                  {r.logoData ? "Real logo" : "Logo designed"}
                </span>
              </div>
              {r.description && <p className="text-[11px] leading-snug text-ink-400">{r.description}</p>}
              {r.officialName && <p className="text-[10px] text-ink-500">Official name: {r.officialName}</p>}
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {[
              r.hq && `${r.hq}${r.country && !/united states/i.test(r.country) ? `, ${r.country}` : ""}`,
              INDUSTRY_NAME[r.industry],
              r.founded && `Founded ${r.founded}`,
              r.employees ? `${formatEmployees(r.employees)} employees` : "",
            ]
              .filter(Boolean)
              .map((f) => (
                <span key={f as string} className="rounded-full border border-ink-700 px-2 py-0.5 text-[10px] font-medium text-ink-300">
                  {f}
                </span>
              ))}
          </div>

          {r.summary && <p className="line-clamp-3 text-[11px] leading-relaxed text-ink-400">{r.summary}</p>}

          <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] font-semibold">
            {r.website && (
              <a href={r.website} target="_blank" rel="noreferrer" className="text-ink-300 underline-offset-2 hover:text-ember-400 hover:underline">
                {hostOf(r.website)}
                <Ext />
              </a>
            )}
            {r.article && (
              <a href={r.article} target="_blank" rel="noreferrer" className="text-ink-300 underline-offset-2 hover:text-ember-400 hover:underline">
                Wikipedia
                <Ext />
              </a>
            )}
            <a
              href={`https://www.wikidata.org/wiki/${r.qid}`}
              target="_blank"
              rel="noreferrer"
              className="text-ink-300 underline-offset-2 hover:text-ember-400 hover:underline"
            >
              Wikidata
              <Ext />
            </a>
          </div>

          {p.state.alternatives.length > 0 && (
            <div className="border-t border-ink-700/70 pt-2">
              <div className="mb-1.5 text-[10px] font-bold uppercase tracking-[0.12em] text-ink-500">Not it? Other matches</div>
              <div className="flex flex-wrap gap-1.5">
                {p.state.alternatives.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => p.onPickAlternative(c)}
                    title={c.description}
                    className="max-w-full truncate rounded-full border border-ink-700 px-2.5 py-0.5 text-[11px] text-ink-300 transition-colors hover:border-ember-500/60 hover:text-ink-100"
                  >
                    {c.label}
                    {c.description && <span className="text-ink-500"> · {c.description}</span>}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {p.recent.length > 0 && (
        <div>
          <div className="mb-1.5 flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.12em] text-ink-500">
            <span>Recently researched · {p.recent.length}</span>
            <button type="button" onClick={p.onClear} className="font-semibold normal-case tracking-normal text-ink-400 hover:text-ember-400">
              Clear
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {p.recent.slice(0, 8).map((o) => (
              <button
                key={o.id}
                type="button"
                onClick={() => p.onPickRecent(o.id)}
                aria-pressed={o.id === p.activeId}
                className={cn(
                  "flex max-w-[170px] items-center gap-1.5 rounded-full border py-0.5 pl-0.5 pr-2.5 text-[11px] transition-colors",
                  o.id === p.activeId
                    ? "border-ember-500/70 bg-ember-500/10 text-ember-200"
                    : "border-ink-700 text-ink-300 hover:border-ink-500 hover:text-ink-100"
                )}
              >
                <LogoBox r={o} size="sm" />
                <span className="truncate">{o.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <p className="text-[10px] leading-snug text-ink-600">
        Names, facts and logos come from Wikidata, Wikipedia and Wikimedia Commons. Vague descriptions are interpreted by an AI
        language model (Pollinations), then checked against Wikidata, so names are never invented. Researched companies are added
        to your directory.
      </p>
    </div>
  );
}
