import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import {
  COMPANIES,
  COMPANY_MAP,
  SP500_COUNT,
  formatEmployees,
  searchCompanies,
  type Company,
  type CompanyGroup,
} from "../lib/companies";
import { INDUSTRIES, INDUSTRY_NAME } from "../lib/industries";
import { bundledCompanyLogoUrl, hasCompanyLogo } from "../lib/logos";
import { orgInitials } from "../lib/logoStudio";
import { looksLikeOrg, searchOrgs, type Candidate, type ResearchedOrg } from "../lib/research";
import type { IndustryId } from "../types";

interface Props {
  /** "custom", a directory id, or a researched id ("wd:Q…") */
  value: string;
  customName: string;
  onChange: (id: string) => void;
  /** the logo the card is currently using (may be a real logo loaded online or a generated concept) */
  selectedLogo?: { src: string; contain: boolean } | null;
  /** companies added by the research assistant */
  researched: ResearchedOrg[];
  /** research a company (by name, optionally a specific Wikidata item) */
  onResearch: (query: string, qid?: string) => void;
}

const PAGE = 60;
const TILE = ["#2563eb", "#dc2626", "#059669", "#d97706", "#7c3aed", "#0891b2", "#db2777", "#ea580c", "#0f766e", "#475569"];
const GROUPS: { v: CompanyGroup; label: string }[] = [
  { v: "all", label: "All" },
  { v: "sp500", label: "S&P 500" },
  { v: "other", label: "Other" },
];

function tileColor(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return TILE[h % TILE.length];
}

function Initials({ name, className }: { name: string; className: string }) {
  return (
    <span
      className={cn(className, "flex shrink-0 items-center justify-center rounded-lg text-[11px] font-bold text-white")}
      style={{ background: tileColor(name) }}
    >
      {orgInitials(name)}
    </span>
  );
}

function Thumb({ c, className }: { c: Company; className: string }) {
  const src = bundledCompanyLogoUrl(c.id);
  if (src) return <img src={src} alt="" loading="lazy" className={cn(className, "shrink-0 rounded-lg bg-white object-contain p-1")} />;
  return <Initials name={c.name} className={className} />;
}

function RThumb({ r, className }: { r: ResearchedOrg; className: string }) {
  if (r.logoData)
    return <img src={r.logoData} alt="" className={cn(className, "shrink-0 rounded-lg object-contain p-1", r.logoDark ? "bg-ink-900" : "bg-white")} />;
  return <Initials name={r.name} className={className} />;
}

function subline(c: Company) {
  return [c.hq, INDUSTRY_NAME[c.industry], c.employees ? `${formatEmployees(c.employees)} employees` : ""].filter(Boolean).join(" · ");
}

function rSubline(r: ResearchedOrg) {
  return [r.hq, INDUSTRY_NAME[r.industry], r.description].filter(Boolean).join(" · ");
}

/**
 * Searchable dropdown: companies you've researched, the built-in directory (S&P 500, large U.S. employers,
 * well-known private companies & nonprofits) and live matches from Wikidata that can be researched in one click.
 */
export function CompanyPicker({ value, customName, onChange, selectedLogo, researched, onResearch }: Props) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [industry, setIndustry] = useState<IndustryId | "all">("all");
  const [group, setGroup] = useState<CompanyGroup>("all");
  const [limit, setLimit] = useState(PAGE);
  const [active, setActive] = useState(0);
  const [online, setOnline] = useState<{ items: Candidate[]; loading: boolean; error: boolean }>({ items: [], loading: false, error: false });
  const wrapRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = value !== "custom" ? COMPANY_MAP.get(value) ?? null : null;
  const selectedR = researched.find((r) => r.id === value) ?? null;
  const results = useMemo(() => (open ? searchCompanies(q, industry, group) : []), [open, q, industry, group]);
  const term = q.trim();
  const rList = useMemo(() => {
    const t = term.toLowerCase();
    return researched.filter((r) => !t || `${r.name} ${r.hq} ${r.description}`.toLowerCase().includes(t));
  }, [researched, term]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    listRef.current?.querySelector(`[data-idx="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active, open]);

  // live "found online" matches from Wikidata (debounced)
  useEffect(() => {
    if (!open || term.length < 2) {
      setOnline({ items: [], loading: false, error: false });
      return;
    }
    setOnline((o) => ({ ...o, loading: true, error: false }));
    const ac = new AbortController();
    const timer = window.setTimeout(() => {
      searchOrgs(term, ac.signal, 10)
        .then((items) => {
          const known = new Set(researched.map((r) => r.qid));
          setOnline({ items: items.filter((c) => looksLikeOrg(c.description) && !known.has(c.id)).slice(0, 5), loading: false, error: false });
        })
        .catch(() => {
          if (!ac.signal.aborted) setOnline({ items: [], loading: false, error: true });
        });
    }, 450);
    return () => {
      window.clearTimeout(timer);
      ac.abort();
    };
  }, [open, term, researched]);

  const resetPaging = () => {
    setLimit(PAGE);
    setActive(0);
    listRef.current?.scrollTo({ top: 0 });
  };

  const pick = (id: string) => {
    onChange(id);
    setOpen(false);
    setQ("");
  };

  const research = (query: string, qid?: string) => {
    onResearch(query, qid);
    setOpen(false);
    setQ("");
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      setOpen(false);
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = Math.min(active + 1, results.length - 1);
      if (next >= limit) setLimit((l) => l + PAGE);
      setActive(next);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => Math.max(0, a - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const r = results[active];
      if (r) pick(r.id);
      else if (term.length >= 2) research(term);
    }
  };

  const shown = results.slice(0, limit);
  const header = "flex items-center justify-between px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-[0.12em] text-ink-500";

  return (
    <div ref={wrapRef} className="relative">
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Choose a company or organization"
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex h-14 w-full items-center gap-3 rounded-lg border bg-ink-850 px-3 text-left transition-colors",
          open ? "border-ember-500/70" : "border-ink-700 hover:border-ink-500"
        )}
      >
        {selectedLogo ? (
          <img
            src={selectedLogo.src}
            alt=""
            className={cn("h-9 w-9 shrink-0 rounded-lg bg-white", selectedLogo.contain ? "object-contain p-1" : "object-cover")}
          />
        ) : selected ? (
          <Thumb c={selected} className="h-9 w-9" />
        ) : selectedR ? (
          <RThumb r={selectedR} className="h-9 w-9" />
        ) : (
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-ink-700 text-ink-300">
            <Icon name="building" className="h-5 w-5" />
          </span>
        )}
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-semibold text-ink-50">
            {selected ? selected.name : selectedR ? selectedR.name : customName.trim() || "Your organization"}
          </span>
          <span className="block truncate text-[11px] text-ink-400">
            {selected ? subline(selected) : selectedR ? `Researched · ${rSubline(selectedR)}` : "Custom organization · AI logo studio"}
          </span>
        </span>
        <Icon name="chevron" className={cn("h-4 w-4 shrink-0 text-ink-400 transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        <div
          className="fade-up absolute inset-x-0 top-full z-40 mt-2 overflow-hidden rounded-xl border border-ink-600 bg-ink-900 shadow-[0_24px_60px_-12px_rgba(0,0,0,0.7)]"
          onKeyDown={onKey}
        >
          <div className="relative border-b border-ink-700 p-2.5">
            <Icon name="search" className="pointer-events-none absolute left-5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input
              ref={inputRef}
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                resetPaging();
              }}
              placeholder="Search company, city or ticker…"
              aria-label="Search companies"
              className="h-10 w-full rounded-lg border border-ink-700 bg-ink-850 pl-9 pr-3 text-sm text-ink-100 outline-none placeholder:text-ink-500 focus:border-ember-500/70"
            />
          </div>

          <div className="flex items-center gap-2 border-b border-ink-700 px-2.5 py-2">
            <select
              aria-label="Filter by industry"
              value={industry}
              onChange={(e) => {
                setIndustry(e.target.value as IndustryId | "all");
                resetPaging();
              }}
              className="h-8 min-w-0 flex-1 rounded-md border border-ink-700 bg-ink-850 px-2 text-xs font-medium text-ink-200 outline-none focus:border-ember-500/70"
            >
              <option value="all">All industries</option>
              {INDUSTRIES.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name}
                </option>
              ))}
            </select>
            <div className="flex shrink-0 gap-0.5 rounded-md border border-ink-700 bg-ink-850 p-0.5">
              {GROUPS.map((g) => (
                <button
                  key={g.v}
                  type="button"
                  onClick={() => {
                    setGroup(g.v);
                    resetPaging();
                  }}
                  className={cn(
                    "h-7 rounded px-2 text-[11px] font-semibold transition-colors",
                    group === g.v ? "bg-ink-600 text-ink-50" : "text-ink-400 hover:text-ink-200"
                  )}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </div>

          <div ref={listRef} role="listbox" className="slim-scroll max-h-[340px] overflow-y-auto pb-1.5"
            onScroll={(e) => {
              const el = e.currentTarget;
              if (el.scrollTop + el.clientHeight > el.scrollHeight - 240 && limit < results.length) setLimit((l) => l + PAGE);
            }}
          >
            <button
              type="button"
              onClick={() => pick("custom")}
              className={cn(
                "flex w-full items-center gap-3 border-b border-ink-700 px-3 py-2.5 text-left transition-colors hover:bg-ink-800",
                value === "custom" && "bg-ember-500/10"
              )}
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-ember-500/15 text-ember-400">
                <Icon name="sparkle" className="h-4 w-4" strokeWidth={2} />
              </span>
              <span className="min-w-0">
                <span className="block text-[13px] font-semibold text-ink-100">Custom organization</span>
                <span className="block text-[11px] text-ink-400">Type any name — the AI logo studio designs concepts for it</span>
              </span>
            </button>

            {rList.length > 0 && (
              <>
                <div className={header}>
                  <span>Researched by you · {rList.length}</span>
                </div>
                {rList.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    role="option"
                    aria-selected={r.id === value}
                    onClick={() => pick(r.id)}
                    className={cn("flex w-full items-center gap-3 px-3 py-2 text-left transition-colors hover:bg-ink-800", r.id === value && "bg-ember-500/10")}
                  >
                    <RThumb r={r} className="h-8 w-8" />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-1.5">
                        <span className="truncate text-[13px] font-semibold text-ink-100">{r.name}</span>
                        <span
                          className={cn(
                            "shrink-0 rounded px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide",
                            r.logoData ? "bg-emerald-500/15 text-emerald-400" : "bg-ember-500/15 text-ember-400"
                          )}
                        >
                          {r.logoData ? "Real logo" : "Designed"}
                        </span>
                      </span>
                      <span className="block truncate text-[11px] text-ink-400">{rSubline(r)}</span>
                    </span>
                    {r.id === value && <Icon name="check" className="h-4 w-4 shrink-0 text-ember-400" strokeWidth={2.6} />}
                  </button>
                ))}
              </>
            )}

            <div className={header}>
              <span>
                Directory · {results.length.toLocaleString()} of {COMPANIES.length.toLocaleString()}
              </span>
              <span className="font-medium normal-case tracking-normal">{SP500_COUNT} in the S&P 500</span>
            </div>
            {shown.map((c, idx) => {
              const isSel = c.id === value;
              return (
                <button
                  key={c.id}
                  type="button"
                  role="option"
                  aria-selected={isSel}
                  data-idx={idx}
                  onMouseEnter={() => setActive(idx)}
                  onClick={() => pick(c.id)}
                  className={cn(
                    "flex w-full items-center gap-3 px-3 py-2 text-left transition-colors",
                    idx === active ? "bg-ink-800" : "bg-transparent",
                    isSel && "bg-ember-500/10"
                  )}
                >
                  <Thumb c={c} className="h-8 w-8" />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-[13px] font-semibold text-ink-100">{c.name}</span>
                      {hasCompanyLogo(c.id) && (
                        <span className="shrink-0 rounded bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-emerald-400">
                          Real logo
                        </span>
                      )}
                      {c.sp500 && (
                        <span className="shrink-0 rounded bg-ink-700 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-ink-300">
                          {c.id}
                        </span>
                      )}
                    </span>
                    <span className="block truncate text-[11px] text-ink-400">{subline(c)}</span>
                  </span>
                  {isSel && <Icon name="check" className="h-4 w-4 shrink-0 text-ember-400" strokeWidth={2.6} />}
                </button>
              );
            })}
            {results.length === 0 && term.length < 2 && (
              <div className="px-4 py-6 text-center text-xs text-ink-500">No organizations match these filters.</div>
            )}
            {limit < results.length && (
              <button
                type="button"
                onClick={() => setLimit((l) => l + PAGE * 3)}
                className="mx-3 mt-1 w-[calc(100%-1.5rem)] rounded-lg border border-ink-700 py-2 text-xs font-semibold text-ink-300 hover:border-ink-500 hover:text-ink-100"
              >
                Show more ({(results.length - limit).toLocaleString()} left)
              </button>
            )}

            {term.length >= 2 && (
              <>
                <div className={header}>
                  <span>Found online · Wikidata</span>
                  {online.loading && <span className="h-3 w-3 animate-spin rounded-full border-2 border-ink-600 border-t-ember-400" />}
                </div>
                {online.items.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => research(c.label, c.id)}
                    className="flex w-full items-center gap-3 px-3 py-2 text-left transition-colors hover:bg-ink-800"
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-dashed border-ink-600 text-ink-400">
                      <Icon name="search" className="h-3.5 w-3.5" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-semibold text-ink-100">{c.label}</span>
                      <span className="block truncate text-[11px] text-ink-400">{c.description}</span>
                    </span>
                    <span className="shrink-0 rounded bg-ember-500/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-ember-400">
                      Research
                    </span>
                  </button>
                ))}
                {!online.loading && online.error && (
                  <div className="px-3 py-1.5 text-[11px] text-ink-500">Couldn’t reach Wikidata — you can still research it below.</div>
                )}
                <button
                  type="button"
                  onClick={() => research(term)}
                  className="mx-3 mt-1.5 flex w-[calc(100%-1.5rem)] items-center justify-center gap-2 rounded-lg border border-ember-500/40 bg-ember-500/10 py-2 text-xs font-bold text-ember-300 transition-colors hover:bg-ember-500/20"
                >
                  <Icon name="sparkle" className="h-3.5 w-3.5" strokeWidth={2.2} />
                  Research “{term}” with the assistant
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
