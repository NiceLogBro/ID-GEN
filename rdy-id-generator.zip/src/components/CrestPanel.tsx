import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import type { CrestGuess } from "../lib/institutions";

export type RealStatus = "idle" | "loading" | "found" | "none" | "error";

interface Props {
  guesses: CrestGuess[];
  index: number;
  status: RealStatus;
  onPick: (i: number) => void;
  /** school color (detected from the official logo, or the generated crest's palette) */
  brand?: string;
  onApplyColors?: () => void;
}

const KIND_LABEL: Record<CrestGuess["kind"], string> = {
  real: "Real logo",
  ai: "AI-drawn guess",
  generated: "Auto-drawn guess",
};

const KIND_STYLE: Record<CrestGuess["kind"], string> = {
  real: "bg-emerald-500/15 text-emerald-400",
  ai: "bg-ember-500/15 text-ember-400",
  generated: "bg-ink-700 text-ink-300",
};

/** Shows which logo the card uses: the real one when we could find it, otherwise a drawn guess. */
export function CrestPanel({ guesses, index, status, onPick, brand, onApplyColors }: Props) {
  const g = guesses[index] ?? guesses[0];
  if (!g) return null;

  return (
    <div className="fade-up space-y-2.5 rounded-lg border border-ink-700 bg-ink-850 p-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-ink-300">Logo on the card</span>
        <span className="text-[10px] tabular-nums text-ink-500">
          {index + 1} of {guesses.length}
        </span>
      </div>

      {status === "loading" && (
        <div className="flex items-center gap-2 text-[11px] text-ink-400">
          <span className="h-3 w-3 animate-spin rounded-full border-2 border-ink-500 border-t-ember-400" />
          Looking for the official logo…
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        {guesses.map((c, i) => (
          <button
            key={`${c.kind}-${i}`}
            type="button"
            aria-label={`Use ${KIND_LABEL[c.kind].toLowerCase()} ${i + 1}`}
            aria-pressed={i === index}
            onClick={() => onPick(i)}
            className={cn(
              "relative h-11 w-11 shrink-0 overflow-hidden rounded-lg border-2 transition-all",
              c.dark ? "bg-ink-900" : "bg-white",
              i === index
                ? "border-ember-500 shadow-[0_0_0_3px_rgba(249,123,22,0.15)]"
                : "border-ink-600 opacity-60 hover:opacity-100"
            )}
          >
            <img
              src={c.src}
              alt=""
              className={cn("h-full w-full", c.fit === "contain" ? "object-contain p-1" : "object-cover")}
              draggable={false}
            />
            {c.kind === "real" && (
              <span className="absolute -right-0.5 -top-0.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-emerald-500 text-ink-950">
                <Icon name="check" className="h-2.5 w-2.5" strokeWidth={3.5} />
              </span>
            )}
          </button>
        ))}
        <button
          type="button"
          title="Next logo"
          aria-label="Next logo"
          onClick={() => onPick((index + 1) % guesses.length)}
          className="flex h-11 w-11 shrink-0 flex-col items-center justify-center gap-0.5 rounded-lg border border-ink-600 text-ink-300 transition-colors hover:border-ember-500/60 hover:text-ember-400"
        >
          <Icon name="dice" className="h-4 w-4" />
          <span className="text-[8px] font-bold tracking-wide">NEXT</span>
        </button>
      </div>

      <p className="text-[11px] leading-snug text-ink-400">
        <span className={cn("mr-1.5 inline-block rounded px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide", KIND_STYLE[g.kind])}>
          {KIND_LABEL[g.kind]}
        </span>
        {g.blurb}
      </p>

      {brand && onApplyColors && (
        <button
          type="button"
          onClick={onApplyColors}
          className="flex h-9 w-full items-center justify-center gap-2 rounded-lg border border-ink-600 text-[12px] font-semibold text-ink-200 transition-colors hover:border-ember-500/60 hover:text-ember-300"
        >
          <span className="h-3.5 w-3.5 rounded-full ring-1 ring-white/20" style={{ background: brand }} />
          Use school colors on the card
        </button>
      )}

      <p className="text-[10px] leading-snug text-ink-500">
        {g.kind === "real"
          ? "Logos are trademarks of their institutions. Found via Wikidata, hosted on Wikimedia Commons."
          : status === "error"
            ? "Couldn’t reach Wikimedia to load the official logo (offline?) — showing drawn guesses instead."
            : status === "none"
              ? "No official logo found for this school, so these are drawn guesses — not the real mark."
              : "A drawn guess — not the school’s official mark."}
      </p>
    </div>
  );
}
