import { useMemo, useRef } from "react";
import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import {
  AVATAR_COUNT,
  PHOTOGRAPHERS,
  avatarCredit,
  avatarLabel,
  avatarSourceUrl,
  avatarUrl,
} from "../lib/avatars";

interface Props {
  avatarId: number | null;
  photo: string | null;
  initials: string;
  onPick: (id: number) => void;
  onNone: () => void;
  onShuffle: () => void;
  onUpload: (file: File) => void;
  onRemovePhoto: () => void;
}

/** Optional upload + a scrollable grid of 100 real portrait photos. */
export function AvatarPicker({ avatarId, photo, initials, onPick, onNone, onShuffle, onUpload, onRemovePhoto }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const urls = useMemo(() => Array.from({ length: AVATAR_COUNT }, (_, i) => avatarUrl(i)), []);
  const current = photo ?? (avatarId !== null ? urls[avatarId] : null);
  const source = !photo && avatarId !== null ? avatarSourceUrl(avatarId) : null;

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-full bg-ink-700 ring-2 ring-ember-500/60 ring-offset-2 ring-offset-ink-900">
          {current ? (
            <img src={current} alt="Current profile" className="h-full w-full object-cover" />
          ) : (
            <span className="font-display text-lg font-bold text-ink-200">{initials}</span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold text-ink-100">
            {photo
              ? "Your uploaded photo"
              : avatarId !== null
                ? `${avatarLabel(avatarId)} of ${AVATAR_COUNT}`
                : "Initials only"}
          </p>
          <p className="truncate text-[11px] leading-snug text-ink-500">
            {photo ? (
              "Stays on this device — never uploaded anywhere."
            ) : avatarId !== null ? (
              <>
                Photo by {avatarCredit(avatarId)}
                {source && (
                  <>
                    {" · "}
                    <a href={source} target="_blank" rel="noreferrer" className="underline-offset-2 hover:text-ember-400 hover:underline">
                      Pexels
                    </a>
                  </>
                )}
              </>
            ) : (
              "Uploading is optional — pick any portrait below."
            )}
          </p>
        </div>
      </div>

      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="flex h-9 flex-1 items-center justify-center gap-2 rounded-lg border border-dashed border-ink-600 bg-ink-850/60 text-[13px] font-semibold text-ink-300 transition-colors hover:border-ember-500/60 hover:text-ink-100"
        >
          <Icon name="upload" className="h-4 w-4" />
          {photo ? "Replace photo" : "Upload your own"}
        </button>
        <button
          type="button"
          onClick={onShuffle}
          className="flex h-9 items-center gap-2 rounded-lg border border-ink-700 bg-ink-850 px-3 text-[13px] font-semibold text-ink-200 transition-colors hover:border-ink-500"
        >
          <Icon name="dice" className="h-4 w-4" />
          Shuffle
        </button>
        {photo && (
          <button
            type="button"
            aria-label="Remove uploaded photo"
            title="Remove uploaded photo"
            onClick={onRemovePhoto}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-ink-700 text-ink-400 transition-colors hover:border-ink-500 hover:text-ink-100"
          >
            <Icon name="close" className="h-4 w-4" strokeWidth={2.2} />
          </button>
        )}
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onUpload(f);
          e.target.value = "";
        }}
      />

      <div className="rounded-xl border border-ink-700 bg-ink-850/60 p-2">
        <div className="slim-scroll max-h-[252px] overflow-y-auto p-1">
          <div className="grid grid-cols-5 gap-2.5">
            <button
              type="button"
              onClick={onNone}
              aria-label="No picture, use initials"
              title="No picture (initials)"
              className={cn(
                "flex aspect-square items-center justify-center rounded-full border border-dashed text-[11px] font-extrabold tracking-wide transition-colors",
                !photo && avatarId === null
                  ? "border-ember-500 bg-ember-500/10 text-ember-400"
                  : "border-ink-600 text-ink-400 hover:border-ink-400 hover:text-ink-200"
              )}
            >
              AB
            </button>
            {urls.map((u, i) => {
              const on = !photo && avatarId === i;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => onPick(i)}
                  aria-label={`${avatarLabel(i)}, photo by ${avatarCredit(i)}`}
                  aria-pressed={on}
                  title={`${avatarLabel(i)} · photo by ${avatarCredit(i)}`}
                  className={cn(
                    "aspect-square overflow-hidden rounded-full bg-ink-700 transition-all",
                    on
                      ? "ring-2 ring-ember-500 ring-offset-2 ring-offset-ink-850"
                      : "opacity-90 hover:scale-105 hover:opacity-100"
                  )}
                >
                  <img src={u} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover" draggable={false} />
                </button>
              );
            })}
          </div>
        </div>
        <p className="px-1 pb-0.5 pt-2 text-center text-[10px] text-ink-500">
          {AVATAR_COUNT} real portrait photos · scroll for more
        </p>
      </div>

      <details className="group rounded-lg border border-ink-800 px-3 py-2 text-[11px] text-ink-500">
        <summary className="cursor-pointer select-none font-semibold text-ink-400 marker:text-ink-600 hover:text-ink-200">
          Photo credits
        </summary>
        <p className="mt-2 leading-relaxed">
          Stock photos from{" "}
          <a href="https://www.pexels.com" target="_blank" rel="noreferrer" className="text-ink-300 underline-offset-2 hover:text-ember-400 hover:underline">
            Pexels
          </a>{" "}
          (free to use under the Pexels License). Thank you to: {PHOTOGRAPHERS.join(", ")}.
        </p>
      </details>
    </div>
  );
}
