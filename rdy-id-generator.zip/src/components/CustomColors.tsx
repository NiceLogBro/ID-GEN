import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import { Switch } from "./ui";
import { CUSTOM_PRESETS, normalizeHex, type Palette } from "../lib/styles";
import type { CustomColorSet } from "../types";

interface Props {
  enabled: boolean;
  colors: CustomColorSet;
  /** the selected style's palette — used for "reset" */
  base: Palette;
  onToggle: (v: boolean) => void;
  onChange: (patch: Partial<CustomColorSet>) => void;
  onReset: () => void;
}

const ROWS: { key: keyof CustomColorSet; label: string; hint: string }[] = [
  { key: "bg", label: "Card background", hint: "Main card color" },
  { key: "accent", label: "Accent", hint: "Headers, rings & details" },
  { key: "text", label: "Text", hint: "Name & headings" },
  { key: "plate", label: "ID plate", hint: "The ID number panel" },
];

function ColorRow({
  label,
  hint,
  value,
  onCommit,
}: {
  label: string;
  hint: string;
  value: string;
  onCommit: (v: string) => void;
}) {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  const commit = () => {
    const next = normalizeHex(text, value);
    setText(next);
    if (next !== value) onCommit(next);
  };
  return (
    <div className="flex items-center gap-2.5 rounded-lg border border-ink-700 bg-ink-850 px-2.5 py-2">
      <label
        className="relative h-9 w-9 shrink-0 cursor-pointer overflow-hidden rounded-lg ring-1 ring-white/15 focus-within:ring-2 focus-within:ring-ember-500/80"
        style={{ background: value }}
        title={`Pick ${label.toLowerCase()}`}
      >
        <input
          type="color"
          aria-label={`Pick ${label.toLowerCase()}`}
          className="swatch absolute inset-0 opacity-0"
          value={value}
          onChange={(e) => onCommit(e.target.value)}
        />
      </label>
      <div className="min-w-0 flex-1">
        <div className="text-xs font-bold text-ink-100">{label}</div>
        <div className="text-[10px] text-ink-500">{hint}</div>
      </div>
      <input
        value={text}
        spellCheck={false}
        maxLength={7}
        aria-label={`${label} hex value`}
        onChange={(e) => setText(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") (e.target as HTMLInputElement).blur();
        }}
        className="h-8 w-[76px] shrink-0 rounded-md border border-ink-700 bg-ink-900 px-2 font-mono text-xs lowercase text-ink-200 outline-none focus:border-ember-500/70"
      />
    </div>
  );
}

/** Optional color overrides for whichever card style is selected. */
export function CustomColors({ enabled, colors, base, onToggle, onChange, onReset }: Props) {
  return (
    <div className="space-y-3">
      <Switch checked={enabled} onChange={onToggle} label="Custom colors" />
      {enabled && (
        <div className="fade-up space-y-2.5 rounded-xl border border-ink-700 bg-ink-850/50 p-3">
          <div className="grid grid-cols-1 gap-2">
            {ROWS.map((r) => (
              <ColorRow
                key={r.key}
                label={r.label}
                hint={r.hint}
                value={colors[r.key]}
                onCommit={(v) => onChange({ [r.key]: v })}
              />
            ))}
          </div>
          <div>
            <div className="mb-1.5 text-[11px] font-semibold text-ink-400">One-tap looks</div>
            <div className="flex flex-wrap gap-1.5">
              {CUSTOM_PRESETS.map((p) => (
                <button
                  key={p.name}
                  type="button"
                  title={p.name}
                  aria-label={`Use the ${p.name} look`}
                  onClick={() => onChange({ bg: p.bg, accent: p.accent, text: p.text, plate: p.plate })}
                  className="flex h-8 w-8 items-center justify-center rounded-full ring-1 ring-white/15 transition-transform hover:scale-110"
                  style={{ background: p.bg }}
                >
                  <span className="h-3 w-3 rounded-full" style={{ background: p.accent }} />
                </button>
              ))}
            </div>
          </div>
          <button
            type="button"
            onClick={onReset}
            className="flex h-8 w-full items-center justify-center gap-1.5 rounded-lg border border-ink-700 text-xs font-semibold text-ink-400 transition-colors hover:border-ink-500 hover:text-ink-200"
          >
            <Icon name="reset" className="h-3.5 w-3.5" />
            Match the {base.name} style
          </button>
          <p className="text-[11px] leading-snug text-ink-500">
            Applies to any of the 4 styles above — gradients, soft tints and readable text are worked out for you.
          </p>
        </div>
      )}
    </div>
  );
}

// re-exported so App can show the active dot without importing styles twice
export function CustomDot({ colors, className }: { colors: CustomColorSet; className?: string }) {
  return (
    <span
      className={cn("inline-block h-3 w-3 rounded-full ring-1 ring-white/20", className)}
      style={{ background: `linear-gradient(135deg, ${colors.bg} 50%, ${colors.accent} 50%)` }}
    />
  );
}
