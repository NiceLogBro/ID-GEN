import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import { SCENES } from "../lib/scenes";
import type { SceneId } from "../types";

interface Props {
  value: SceneId;
  onPick: (id: SceneId) => void;
  onRandom: () => void;
  onSave: () => void;
  saving: boolean;
}

/** Preview backdrop picker: plain studio or one of 4 simple surface scenes + randomizer + save. */
export function ScenePicker({ value, onPick, onRandom, onSave, saving }: Props) {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={() => onPick("studio")}
          aria-pressed={value === "studio"}
          aria-label="Studio backdrop (no photo)"
          className={cn(
            "relative h-[68px] overflow-hidden rounded-xl border text-left transition-all",
            value === "studio"
              ? "border-ember-500/80 shadow-[0_0_0_3px_rgba(249,123,22,0.12)]"
              : "border-ink-700 hover:border-ink-500"
          )}
        >
          <span className="dotgrid absolute inset-0 bg-ink-950" />
          <span className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-ink-950/80 px-2 py-1 text-[10px] font-bold text-ink-200">
            Studio
            {value === "studio" && <Icon name="check" className="h-3 w-3 text-ember-400" strokeWidth={3} />}
          </span>
        </button>
        {SCENES.map((s) => {
          const on = value === s.id;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => onPick(s.id)}
              aria-pressed={on}
              aria-label={`${s.name} backdrop — ${s.blurb}`}
              title={`${s.name} — ${s.blurb}`}
              className={cn(
                "relative h-[68px] overflow-hidden rounded-xl border text-left transition-all",
                on
                  ? "border-ember-500/80 shadow-[0_0_0_3px_rgba(249,123,22,0.12)]"
                  : "border-ink-700 hover:border-ink-500"
              )}
            >
              <img src={s.src} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover" draggable={false} />
              <span className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-ink-950/80 px-2 py-1 text-[10px] font-bold text-ink-200">
                <span className="truncate">{s.name}</span>
                {on && <Icon name="check" className="h-3 w-3 shrink-0 text-ember-400" strokeWidth={3} />}
              </span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={onRandom}
          aria-label="Random realistic backdrop"
          title="Random realistic backdrop"
          className="flex h-[68px] flex-col items-center justify-center gap-1 rounded-xl border border-dashed border-ink-600 text-ink-300 transition-colors hover:border-ember-500/60 hover:text-ember-400"
        >
          <Icon name="dice" className="h-5 w-5" />
          <span className="text-[10px] font-extrabold uppercase tracking-wide">Surprise me</span>
        </button>
      </div>
      <button
        type="button"
        onClick={onSave}
        disabled={saving}
        className="flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-ember-500 text-[13px] font-bold text-ink-950 transition-colors hover:bg-ember-400 disabled:cursor-wait disabled:opacity-70"
      >
        {saving ? (
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-ink-950/40 border-t-ink-950" />
        ) : (
          <Icon name="camera" className="h-4 w-4" strokeWidth={2} />
        )}
        {saving ? "Saving…" : "Save picture"}
      </button>
      <p className="text-[11px] leading-snug text-ink-500">
        Save picture captures the card on this backdrop (1600 × 1000). The Export PNG button up top always
        saves the card alone. Photos via Pexels: {Array.from(new Set(SCENES.map((s) => s.credit))).join(", ")}.
      </p>
    </div>
  );
}
