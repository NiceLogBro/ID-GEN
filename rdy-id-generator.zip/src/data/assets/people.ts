// Index of the bundled portrait chunks (order matches PORTRAIT_CREDITS).
import p0 from "./people-0";
import p1 from "./people-1";
import p2 from "./people-2";
import p3 from "./people-3";

const PEOPLE: string[] = [...p0, ...p1, ...p2, ...p3];
export default PEOPLE;
