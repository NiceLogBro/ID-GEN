// Generated — bundled company logos (Wikimedia Commons), WebP, stored as text so they survive resets.
import m0 from "./companyLogos-0";

export const COMPANY_LOGOS: Record<string, string> = { ...m0 };
