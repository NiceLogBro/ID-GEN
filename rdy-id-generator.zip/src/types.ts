export type Orientation = "portrait" | "landscape";
export type CapsMode = "auto" | "upper" | "title";
export type Role = "student" | "intern" | "staff";
/** "studio" = the plain dark preview; the rest are simple high-contrast surface backdrops (preview only) */
export type SceneId = "studio" | "granite" | "walnut" | "marble" | "slate";
/** what kind of organization the card is for */
export type OrgMode = "university" | "company";
export type IndustryId =
  | "technology"
  | "finance"
  | "healthcare"
  | "retail"
  | "food"
  | "energy"
  | "manufacturing"
  | "transportation"
  | "automotive"
  | "aerospace"
  | "media"
  | "hospitality"
  | "construction"
  | "professional"
  | "education"
  | "nonprofit"
  | "general";

export interface CustomColorSet {
  bg: string;
  accent: string;
  text: string;
  plate: string;
}

export interface BadgeData {
  name: string;
  title: string;
  department: string;
  /** custom organization name (used when companyId is "custom") */
  company: string;
  /** "none" or an IPEDS unit id */
  college: string;
  /** which crest guess of the institution */
  guess: number;
  empId: string;
  role: Role;
  expires: string; // yyyy-mm-dd
  orientation: Orientation;
  /** which generated set of 4 card styles (0 = the original curated set) */
  styleSeed: number;
  /** which of the 4 styles in the set */
  styleIndex: number;
  caps: CapsMode;
  showQr: boolean;
  showBarcode: boolean;
  /** uploaded photo (data URL) — optional, overrides the avatar */
  photo: string | null;
  /** 0–99 built-in profile picture, or null for initials */
  avatarId: number | null;
  /** when true, the custom colors below override the selected style's palette */
  customOn: boolean;
  customBg: string;
  customAccent: string;
  customText: string;
  customPlate: string;
  /** preview backdrop — "studio" or one of the 4 photo scenes (never affects the PNG export) */
  scene: SceneId;
  /** university or company / organization */
  orgMode: OrgMode;
  /** "custom" (type your own) or a company-directory id */
  companyId: string;
  /** "auto" = detected from the directory (or defaults) */
  industry: IndustryId | "auto";
  /** "" = auto (detected from the official logo, or picked from the name) */
  brandColor: string;
  /** which set of generated logo concepts */
  logoSeed: number;
  /** which logo option (the real logo first when found, then concepts) */
  logoPick: number;
}

export const ROLES: Role[] = ["student", "intern", "staff"];

export const ROLE_LABEL: Record<Role, string> = {
  student: "Student",
  intern: "Intern",
  staff: "Staff",
};

export const ROLE_ID_LABEL: Record<Role, string> = {
  student: "STUDENT ID",
  intern: "INTERN ID",
  staff: "STAFF ID",
};

export const ROLE_FIELDS: Record<
  Role,
  { title: string; titlePh: string; dept: string; deptPh: string }
> = {
  student: {
    title: "Major / program",
    titlePh: "Computer Science",
    dept: "School / college",
    deptPh: "Engineering",
  },
  intern: {
    title: "Position",
    titlePh: "Design Intern",
    dept: "Team",
    deptPh: "Brand Studio",
  },
  staff: {
    title: "Job title",
    titlePh: "Program Coordinator",
    dept: "Department",
    deptPh: "Admissions",
  },
};
