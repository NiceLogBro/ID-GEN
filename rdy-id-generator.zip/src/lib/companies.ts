import { RAW_COMPANIES } from "../data/companies";
import type { IndustryId } from "../types";

export interface Company {
  /** stock ticker (S&P 500) or Wikidata id */
  id: string;
  name: string;
  hq: string;
  industry: IndustryId;
  sp500: boolean;
  employees: number;
  lname: string;
  hay: string;
}

export type CompanyGroup = "all" | "sp500" | "other";

export const COMPANIES: Company[] = RAW_COMPANIES.map(([id, name, hq, industry, sp, employees]) => ({
  id,
  name,
  hq,
  industry: industry as IndustryId,
  sp500: sp === 1,
  employees,
  lname: name.toLowerCase(),
  hay: `${name} ${hq} ${id}`.toLowerCase(),
}));

export const COMPANY_MAP = new Map(COMPANIES.map((c) => [c.id, c]));
export const SP500_COUNT = COMPANIES.filter((c) => c.sp500).length;

export function formatEmployees(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`;
  if (n >= 1_000) return `${Math.round(n / 1_000)}K`;
  return String(n);
}

/**
 * Search the directory. With no query the list is ordered by size (biggest employers first),
 * so the most recognizable organizations are on top; with a query, best matches come first.
 */
export function searchCompanies(query: string, industry: IndustryId | "all", group: CompanyGroup): Company[] {
  const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
  const q = tokens.join(" ");
  let list = COMPANIES;
  if (industry !== "all") list = list.filter((c) => c.industry === industry);
  if (group === "sp500") list = list.filter((c) => c.sp500);
  if (group === "other") list = list.filter((c) => !c.sp500);
  if (tokens.length) list = list.filter((c) => tokens.every((t) => c.hay.includes(t)));

  const rank = (c: Company) => {
    if (!tokens.length) return 0;
    if (c.id.toLowerCase() === q) return -1;
    if (c.lname.startsWith(q)) return 0;
    if (c.lname.includes(" " + q)) return 1;
    return 2;
  };
  return list
    .map((c) => ({ c, r: rank(c) }))
    .sort(
      (a, b) =>
        a.r - b.r ||
        b.c.employees - a.c.employees ||
        Number(b.c.sp500) - Number(a.c.sp500) ||
        a.c.name.localeCompare(b.c.name)
    )
    .map((x) => x.c);
}
