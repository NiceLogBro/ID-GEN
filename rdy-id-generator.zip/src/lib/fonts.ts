import manropeUrl from "@fontsource-variable/manrope/files/manrope-latin-wght-normal.woff2?url";
import groteskUrl from "@fontsource-variable/space-grotesk/files/space-grotesk-latin-wght-normal.woff2?url";

/**
 * Fonts are bundled (no Google Fonts request), so the app works offline and
 * the exported PNG can embed the exact same typefaces inside the card SVG.
 */
const FACES = [
  { family: "Manrope", url: manropeUrl, weight: "200 800" },
  { family: "Space Grotesk", url: groteskUrl, weight: "300 700" },
];

export function installFonts() {
  if (typeof document === "undefined" || document.getElementById("bs-fonts")) return;
  const style = document.createElement("style");
  style.id = "bs-fonts";
  style.textContent = FACES.map(
    (f) =>
      `@font-face{font-family:"${f.family}";src:url("${f.url}") format("woff2");font-weight:${f.weight};font-style:normal;font-display:swap;}`
  ).join("\n");
  document.head.appendChild(style);
}

export const fontsReady: Promise<void> = (async () => {
  try {
    installFonts();
    await Promise.all([
      document.fonts.load('700 20px "Space Grotesk"'),
      document.fonts.load('500 14px "Manrope"'),
      document.fonts.load('800 10px "Manrope"'),
    ]);
  } catch {
    /* fall back to system fonts */
  }
})();

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

let exportCss: Promise<string> | null = null;

/** @font-face rules with the font files inlined as data URLs (for SVG → PNG export). */
export function fontCssForExport(): Promise<string> {
  if (!exportCss) {
    exportCss = Promise.all(
      FACES.map(async (f) => {
        let data = f.url;
        if (!data.startsWith("data:")) {
          const res = await fetch(f.url);
          data = await blobToDataUrl(await res.blob());
        }
        return `@font-face{font-family:"${f.family}";src:url("${data}") format("woff2");font-weight:${f.weight};font-style:normal;}`;
      })
    )
      .then((parts) => parts.join("\n"))
      .catch(() => "");
  }
  return exportCss;
}
