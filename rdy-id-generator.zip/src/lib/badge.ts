import QRCode from "qrcode";
import type { BadgeData, CapsMode } from "../types";
import { ROLE_LABEL } from "../types";

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "•";
  if (parts.length === 1) return Array.from(parts[0]).slice(0, 2).join("").toUpperCase();
  return (Array.from(parts[0])[0] + Array.from(parts[parts.length - 1])[0]).toUpperCase();
}

export function applyCaps(name: string, mode: CapsMode): string {
  if (mode === "upper") return name.toUpperCase();
  if (mode === "title")
    return name
      .toLowerCase()
      .replace(/(^|\s|-|')\S/g, (c) => c.toUpperCase());
  return name;
}

export function genId(role: BadgeData["role"]): string {
  const digits = role === "student" ? 8 : 6;
  const min = Math.pow(10, digits - 1);
  return String(Math.floor(min + Math.random() * 9 * min));
}

export function formatExpiry(iso: string): string {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  if (isNaN(d.getTime())) return "—";
  const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  return `${months[d.getMonth()]} ${d.getFullYear()}`;
}

export function qrPayload(data: BadgeData, institution: string): string {
  return `BSM|${data.name}|${data.empId}|${ROLE_LABEL[data.role]}|EXP ${data.expires}|${institution}`;
}

export async function getQRDataUrl(payload: string): Promise<string> {
  try {
    return await QRCode.toDataURL(payload, {
      margin: 0,
      width: 320,
      errorCorrectionLevel: "M",
      color: { dark: "#14171c", light: "#ffffff" },
    });
  } catch {
    return "";
  }
}

/** deterministic pseudo-barcode bar widths */
export function barcodeBars(seed: string, count: number): number[] {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  let x = h >>> 0;
  const bars: number[] = [];
  for (let i = 0; i < count; i++) {
    x = (Math.imul(x ^ (x >>> 13), 1103515245) + 12345) >>> 0;
    bars.push(1 + (x % 3));
  }
  return bars;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

/** Read an uploaded photo and downscale it so it's cheap to store + embed. */
export async function fileToPhoto(file: File, max = 480): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
  const img = await loadImage(dataUrl);
  const scale = Math.min(1, max / Math.max(img.width, img.height));
  const c = document.createElement("canvas");
  c.width = Math.round(img.width * scale);
  c.height = Math.round(img.height * scale);
  const ctx = c.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.88);
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}
