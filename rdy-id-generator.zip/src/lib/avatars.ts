import { PORTRAIT_CREDITS } from "../data/portraits";
import PEOPLE from "../data/assets/people";

/**
 * 100 built-in profile pictures: real stock photographs of people (Pexels, free to use), cut out onto a
 * grey studio backdrop. They're stored as text modules so they ship inside the app (offline + PNG export).
 */
const URLS: string[] = PEOPLE;

export const AVATAR_COUNT = URLS.length;

export function avatarUrl(i: number): string {
  const n = Math.max(1, URLS.length);
  return URLS[((i % n) + n) % n] ?? "";
}

export function avatarLabel(i: number): string {
  return `Portrait ${i + 1}`;
}

export function avatarCredit(i: number): string {
  return PORTRAIT_CREDITS[i]?.[1] ?? "Pexels";
}

export function avatarSourceUrl(i: number): string | null {
  const c = PORTRAIT_CREDITS[i];
  return c ? `https://www.pexels.com/photo/${c[0]}/` : null;
}

export const PHOTOGRAPHERS: string[] = Array.from(new Set(PORTRAIT_CREDITS.map((c) => c[1]))).sort((a, b) =>
  a.localeCompare(b, undefined, { sensitivity: "base" })
);
