/** Text measuring + fitting, used to lay out the card (SVG has no auto-wrap). */

export type FontKind = "ui" | "display";

const FAMILY: Record<FontKind, string> = {
  ui: 'Manrope, "Helvetica Neue", Arial, sans-serif',
  display: '"Space Grotesk", Manrope, Arial, sans-serif',
};

let ctx: CanvasRenderingContext2D | null | undefined;
let cache = new Map<string, number>();

export function resetTextCache() {
  cache = new Map();
}

export function textWidth(text: string, size: number, weight = 600, kind: FontKind = "ui", ls = 0): number {
  const key = `${kind}|${weight}|${size}|${ls}|${text}`;
  const hit = cache.get(key);
  if (hit !== undefined) return hit;
  if (ctx === undefined) ctx = typeof document !== "undefined" ? document.createElement("canvas").getContext("2d") : null;
  let w: number;
  if (ctx) {
    ctx.font = `${weight} ${size}px ${FAMILY[kind]}`;
    w = ctx.measureText(text).width + ls * text.length;
  } else {
    w = text.length * size * 0.58 + ls * text.length;
  }
  if (cache.size > 4000) cache.clear();
  cache.set(key, w);
  return w;
}

export interface Fit {
  lines: string[];
  size: number;
}

export interface FitOpts {
  maxWidth: number;
  maxLines: number;
  maxSize: number;
  minSize: number;
  /** smallest size allowed while still on a single line (prefer shrinking to wrapping) */
  minSingle?: number;
  weight: number;
  kind: FontKind;
  ls?: number;
}

function wrap(text: string, size: number, o: FitOpts): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const test = cur ? `${cur} ${w}` : w;
    if (cur && textWidth(test, size, o.weight, o.kind, o.ls ?? 0) > o.maxWidth) {
      lines.push(cur);
      cur = w;
    } else {
      cur = test;
    }
  }
  if (cur) lines.push(cur);
  return lines.length ? lines : [text];
}

function ellipsize(text: string, size: number, o: FitOpts): string {
  const ls = o.ls ?? 0;
  if (textWidth(text, size, o.weight, o.kind, ls) <= o.maxWidth) return text;
  let t = text;
  while (t.length > 1 && textWidth(t + "…", size, o.weight, o.kind, ls) > o.maxWidth) {
    t = t.slice(0, -1).trimEnd();
  }
  return t + "…";
}

export function fitLines(text: string, o: FitOpts): Fit {
  const ls = o.ls ?? 0;
  const minSingle = o.minSingle ?? o.minSize;
  for (let n = 1; n <= o.maxLines; n++) {
    const floor = n === 1 && o.maxLines > 1 ? minSingle : o.minSize;
    for (let size = o.maxSize; size >= floor; size -= 0.5) {
      const lines = wrap(text, size, o);
      if (lines.length <= n && lines.every((l) => textWidth(l, size, o.weight, o.kind, ls) <= o.maxWidth)) {
        return { lines, size };
      }
    }
  }
  // Nothing fits cleanly — clamp to min size and add an ellipsis.
  let lines = wrap(text, o.minSize, o);
  if (lines.length > o.maxLines) {
    lines = [...lines.slice(0, o.maxLines - 1), lines.slice(o.maxLines - 1).join(" ")];
  }
  return { lines: lines.map((l) => ellipsize(l, o.minSize, o)), size: o.minSize };
}

export function fitSize(
  text: string,
  maxWidth: number,
  maxSize: number,
  minSize: number,
  weight: number,
  kind: FontKind,
  ls = 0
): number {
  for (let s = maxSize; s > minSize; s -= 0.5) {
    if (textWidth(text, s, weight, kind, ls) <= maxWidth) return s;
  }
  return minSize;
}
