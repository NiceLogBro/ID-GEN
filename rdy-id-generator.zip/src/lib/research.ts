import type { IndustryId } from "../types";
import { formatEmployees } from "./companies";
import { fetchAsDataUrl, processLogoDataUrl, type RealLogo } from "./logos";
import { md5 } from "./md5";

/**
 * Company research assistant. Everything runs in the browser against open, CORS-enabled sources:
 *   1. Wikidata search (+ full-text search for fuzzy names)
 *   2. Candidate comparison — facts via the Wikidata SPARQL endpoint, ranked toward real organizations
 *   3. Optional AI step — a language model (Pollinations) interprets vague descriptions; its answer is then
 *      verified on Wikidata, so names are never made up
 *   4. Facts + Wikipedia summary
 *   5. Official logo: Wikidata logo on Wikimedia Commons → Wikipedia lead image (only if it's a logo)
 *      → the company website's icon (if it's big enough). If none is found, the logo studio designs one.
 */

export interface Candidate {
  id: string;
  label: string;
  description: string;
}

export interface OrgDetails {
  id: string;
  label: string;
  description: string;
  officialName: string;
  logos: string[];
  icons: string[];
  websites: string[];
  founded: string;
  employees: number;
  hq: string[];
  countries: string[];
  industries: string[];
  types: string[];
  sitelinks: number;
  article: string | null;
}

export interface ResearchedOrg {
  /** "wd:Q123" */
  id: string;
  qid: string;
  name: string;
  officialName: string;
  description: string;
  industry: IndustryId;
  industryLabel: string;
  hq: string;
  country: string;
  website: string;
  founded: string;
  employees: number;
  summary: string;
  article: string;
  /** where the logo was fetched from (re-fetched if the cached copy is ever dropped) */
  logoUrl: string | null;
  logoSource: string | null;
  /** processed logo, cached so it keeps working offline */
  logoData: string | null;
  logoAspect: number;
  logoDark: boolean;
  logoBrand: string | null;
  query: string;
  viaAi: string | null;
  researchedAt: number;
}

export type StepStatus = "run" | "ok" | "warn" | "fail";
export interface ResearchStep {
  key: string;
  label: string;
  status: StepStatus;
  detail?: string;
}

export type ResearchOutcome =
  | { kind: "found"; org: ResearchedOrg; alternatives: Candidate[]; viaAi: string | null }
  | { kind: "nomatch"; query: string }
  | { kind: "error"; message: string }
  | { kind: "aborted" };

const WD_API = "https://www.wikidata.org/w/api.php";
const SPARQL = "https://query.wikidata.org/sparql";
const COMMONS_API = "https://commons.wikimedia.org/w/api.php";
const UPLOAD = "https://upload.wikimedia.org/wikipedia/commons/";
const AI_TEXT = "https://text.pollinations.ai/";

/* --------------------------------- network -------------------------------- */

function withTimeout(signal: AbortSignal | undefined, ms: number) {
  const ctl = new AbortController();
  const timer = window.setTimeout(() => ctl.abort(), ms);
  const onAbort = () => ctl.abort();
  if (signal) {
    if (signal.aborted) ctl.abort();
    signal.addEventListener("abort", onAbort);
  }
  return {
    signal: ctl.signal,
    done: () => {
      window.clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
    },
  };
}

async function getJson<T>(url: string, signal?: AbortSignal, ms = 12000): Promise<T> {
  const t = withTimeout(signal, ms);
  try {
    const res = await fetch(url, { signal: t.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as T;
  } finally {
    t.done();
  }
}

/* ------------------------------- text helpers ------------------------------ */

const SUFFIX_RX = /\b(incorporated|inc|corporation|corp|company|co|holdings?|group|plc|ltd|llc|lp|the)\b/g;

export function normName(s: string): string {
  return s
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9 ]+/g, " ")
    .replace(SUFFIX_RX, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const ORG_RX =
  /\b(company|business|enterprise|corporation|organi[sz]ation|brand|conglomerate|retailer|chain|bank|airline|manufacturer|maker|firm|startup|subsidiary|cooperative|nonprofit|non-profit|charity|charitable|foundation|association|publisher|studio|developer|operator|provider|hospital|health system|restaurant|franchise|agency|network|carrier|utility|insurer|insurance|label|broadcaster|newspaper|magazine|university|college|school|institute|society|club|league|team|producer|distributor|supplier|holding|conglomerate|bakery|brewery|winery|creamery|deli|store|shop|marketplace|platform|service)\b/i;
const CREATIVE_RX = /\b(film|album|song|single|novel|book|television series|tv series|episode|video game|character|painting|poem)\b/i;
const NEG_RX =
  /\b(human|family name|given name|surname|city|town|village|municipality|county|province|region|country|river|lake|mountain|island|film|album|single|song|book|novel|television series|episode|video game|fictional|character|taxon|genus|species|fruit|chemical|painting|ship|locomotive|model|product|programming language|protocol|software|website)\b/i;

/** Does a Wikidata description sound like a company / organization? */
export function looksLikeOrg(description: string): boolean {
  return ORG_RX.test(description) && !CREATIVE_RX.test(description);
}

const KW: [RegExp, IndustryId][] = [
  [/hospital|health|medical|pharma|biotech|clinic|nursing|dental/, "healthcare"],
  [/aerospace|defen[cs]e|spacecraft|rocket|satellite/, "aerospace"],
  [/airline|aviation|railroad|railway|logistics|shipping|trucking|freight|transport|courier|parcel/, "transportation"],
  [/automotive|automobile|vehicle|car manufactur/, "automotive"],
  [/bank|financ|insurance|invest|asset management|credit|payment|brokerage|mortgage|accounting/, "finance"],
  [/restaurant|food|beverage|brewing|brewery|drink|grocery|agricultur|meat|dairy|bakery|coffee|fast food|deli|creamery|winery|ice cream|confection|candy|chocolate|snack|cereal|spirits|distiller/, "food"],
  [/video game|media|entertainment|film|television|broadcast|publishing|newspaper|music|advertising|radio|news/, "media"],
  [/software|internet|computer|semiconductor|telecom|information technology|electronics|cloud|technology|artificial intelligence/, "technology"],
  [/oil|petroleum|natural gas|energy|electric|utilit|power|nuclear|solar|coal/, "energy"],
  [/retail|supermarket|department store|store|e-commerce|apparel|clothing|fashion|consumer goods|cosmetic|footwear|outdoor/, "retail"],
  [/hotel|hospitality|casino|travel|tourism|cruise|theme park|resort|leisure/, "hospitality"],
  [/construction|engineering|real estate|architecture|building|homebuild/, "construction"],
  [/consult|law firm|legal|professional services|staffing|human resources|auditing/, "professional"],
  [/education|school|university|college|learning/, "education"],
  [/chemical|steel|manufactur|industrial|machinery|mining|metal|paper|packaging|conglomerate/, "manufacturing"],
  [/nonprofit|non-profit|charity|charitable|foundation|association|society/, "nonprofit"],
];

function industryFrom(d: OrgDetails): IndustryId {
  // the description ("American ice cream company") is usually more specific than Wikidata's broad industry tags
  for (const text of [d.description, d.industries.join(" "), d.types.join(" ")]) {
    const t = text.toLowerCase();
    if (!t) continue;
    for (const [rx, id] of KW) if (rx.test(t)) return id;
  }
  return "general";
}

/* --------------------------------- search --------------------------------- */

/** Wikidata entity search (fast, prefix-based). */
export async function searchOrgs(query: string, signal?: AbortSignal, limit = 10): Promise<Candidate[]> {
  const q = query.trim();
  if (!q) return [];
  const url = `${WD_API}?action=wbsearchentities&format=json&origin=*&language=en&uselang=en&type=item&limit=${limit}&search=${encodeURIComponent(q)}`;
  const j = await getJson<{ search?: { id: string; label?: string; description?: string }[] }>(url, signal);
  return (j.search ?? []).map((s) => ({ id: s.id, label: s.label ?? s.id, description: s.description ?? "" }));
}

/** Wikidata full-text search — catches spellings like "chick fil a". */
async function fulltextSearch(query: string, signal: AbortSignal): Promise<Candidate[]> {
  const url = `${WD_API}?action=query&list=search&format=json&origin=*&srlimit=8&srsearch=${encodeURIComponent(query)}`;
  const j = await getJson<{ query?: { search?: { title: string }[] } }>(url, signal);
  return (j.query?.search ?? [])
    .filter((s) => /^Q\d+$/.test(s.title))
    .map((s) => ({ id: s.title, label: s.title, description: "" }));
}

async function gather(query: string, signal: AbortSignal): Promise<Candidate[]> {
  const out: Candidate[] = [];
  const seen = new Set<string>();
  const add = (c: Candidate) => {
    if (!seen.has(c.id)) {
      seen.add(c.id);
      out.push(c);
    }
  };
  (await searchOrgs(query, signal, 10)).forEach(add);
  if (out.filter((c) => looksLikeOrg(c.description)).length < 2) {
    try {
      (await fulltextSearch(query, signal)).forEach(add);
    } catch (e) {
      if (signal.aborted) throw e;
    }
  }
  return out;
}

/* --------------------------------- details -------------------------------- */

function blank(id: string): OrgDetails {
  return {
    id,
    label: "",
    description: "",
    officialName: "",
    logos: [],
    icons: [],
    websites: [],
    founded: "",
    employees: 0,
    hq: [],
    countries: [],
    industries: [],
    types: [],
    sitelinks: 0,
    article: null,
  };
}

function commonsName(url: string): string {
  try {
    const n = decodeURIComponent(url.split("/Special:FilePath/")[1] ?? "").trim();
    return n ? n.charAt(0).toUpperCase() + n.slice(1) : "";
  } catch {
    return "";
  }
}

function pushUnique(arr: string[], v: string | undefined) {
  if (v && !/^Q\d+$/.test(v) && !arr.includes(v)) arr.push(v);
}

async function detailsViaSparql(ids: string[], signal: AbortSignal): Promise<Map<string, OrgDetails>> {
  const query = `SELECT ?item ?itemLabel ?itemDescription ?logo ?icon ?website ?inception ?employees ?hqLabel ?countryLabel ?industryLabel ?typeLabel ?sitelinks ?article ?officialName WHERE {
VALUES ?item { ${ids.map((id) => `wd:${id}`).join(" ")} }
OPTIONAL { ?item wdt:P154 ?logo }
OPTIONAL { ?item wdt:P8972 ?icon }
OPTIONAL { ?item wdt:P856 ?website }
OPTIONAL { ?item wdt:P571 ?inception }
OPTIONAL { ?item wdt:P1128 ?employees }
OPTIONAL { ?item wdt:P159 ?hq }
OPTIONAL { ?item wdt:P17 ?country }
OPTIONAL { ?item wdt:P452 ?industry }
OPTIONAL { ?item wdt:P31 ?type }
OPTIONAL { ?item wdt:P1448 ?officialName . FILTER(LANG(?officialName) = "en") }
OPTIONAL { ?item wikibase:sitelinks ?sitelinks }
OPTIONAL { ?article schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> }
SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
}`;
  const j = await getJson<{ results: { bindings: Record<string, { value: string }>[] } }>(
    `${SPARQL}?format=json&query=${encodeURIComponent(query)}`,
    signal,
    14000
  );
  const map = new Map<string, OrgDetails>();
  for (const b of j.results.bindings) {
    const id = b.item.value.split("/").pop() ?? "";
    let d = map.get(id);
    if (!d) {
      d = blank(id);
      map.set(id, d);
    }
    const v = (k: string) => b[k]?.value;
    const label = v("itemLabel");
    if (label && !/^Q\d+$/.test(label)) d.label = label;
    if (v("itemDescription")) d.description = v("itemDescription") ?? "";
    if (v("logo")) pushUnique(d.logos, commonsName(v("logo") ?? ""));
    if (v("icon")) pushUnique(d.icons, commonsName(v("icon") ?? ""));
    if (v("website")) pushUnique(d.websites, v("website"));
    const year = /^(\d{3,4})-/.exec(v("inception") ?? "")?.[1];
    if (year && (!d.founded || +year < +d.founded)) d.founded = String(+year);
    const emp = Math.round(Number(v("employees") ?? 0));
    if (Number.isFinite(emp) && emp > d.employees) d.employees = emp;
    pushUnique(d.hq, v("hqLabel"));
    pushUnique(d.countries, v("countryLabel"));
    pushUnique(d.industries, v("industryLabel"));
    pushUnique(d.types, v("typeLabel"));
    const sl = Number(v("sitelinks") ?? 0);
    if (sl > d.sitelinks) d.sitelinks = sl;
    if (v("article")) d.article = v("article") ?? null;
    if (v("officialName")) d.officialName = v("officialName") ?? "";
  }
  return map;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
async function detailsViaEntities(ids: string[], signal: AbortSignal): Promise<Map<string, OrgDetails>> {
  const j: any = await getJson(
    `${WD_API}?action=wbgetentities&format=json&origin=*&props=labels|descriptions|claims|sitelinks&languages=en&sitefilter=enwiki&ids=${ids.join("|")}`,
    signal,
    15000
  );
  const ents: [string, any][] = Object.entries(j.entities ?? {});
  const vals = (claims: any, p: string): any[] => {
    const cs: any[] = (claims?.[p] ?? []).filter((c: any) => c.rank !== "deprecated");
    const pref = cs.filter((c: any) => c.rank === "preferred");
    return (pref.length ? pref : cs).map((c: any) => c.mainsnak?.datavalue?.value).filter((x: any) => x != null);
  };
  const refs = new Set<string>();
  for (const [, e] of ents) for (const p of ["P159", "P17", "P452", "P31"]) for (const x of vals(e.claims, p)) if (x?.id) refs.add(x.id);
  const labels = new Map<string, string>();
  const refList = [...refs];
  for (let i = 0; i < refList.length; i += 50) {
    const lj: any = await getJson(
      `${WD_API}?action=wbgetentities&format=json&origin=*&props=labels&languages=en&ids=${refList.slice(i, i + 50).join("|")}`,
      signal
    );
    for (const [id, e] of Object.entries<any>(lj.entities ?? {})) if (e.labels?.en?.value) labels.set(id, e.labels.en.value);
  }
  const map = new Map<string, OrgDetails>();
  for (const [id, e] of ents) {
    if (e.missing !== undefined) continue;
    const d = blank(id);
    d.label = e.labels?.en?.value ?? id;
    d.description = e.descriptions?.en?.value ?? "";
    d.logos = vals(e.claims, "P154").filter((x) => typeof x === "string");
    d.icons = vals(e.claims, "P8972").filter((x) => typeof x === "string");
    d.websites = vals(e.claims, "P856").filter((x) => typeof x === "string");
    const years = vals(e.claims, "P571")
      .map((x) => /^\+?(\d{3,4})-/.exec(x?.time ?? "")?.[1])
      .filter((x): x is string => !!x);
    if (years.length) d.founded = String(Math.min(...years.map(Number)));
    const emps = vals(e.claims, "P1128")
      .map((x) => Math.round(Number(x?.amount)))
      .filter((x) => Number.isFinite(x) && x > 0);
    if (emps.length) d.employees = Math.max(...emps);
    const lab = (p: string) => vals(e.claims, p).map((x) => labels.get(x?.id)).filter((x): x is string => !!x);
    d.hq = lab("P159");
    d.countries = lab("P17");
    d.industries = lab("P452");
    d.types = lab("P31");
    const title: string | undefined = e.sitelinks?.enwiki?.title;
    if (title) {
      d.article = `https://en.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, "_"))}`;
      d.sitelinks = 1;
    }
    map.set(id, d);
  }
  return map;
}
/* eslint-enable @typescript-eslint/no-explicit-any */

async function fetchDetails(ids: string[], signal: AbortSignal): Promise<Map<string, OrgDetails>> {
  if (!ids.length) return new Map();
  try {
    return await detailsViaSparql(ids.slice(0, 10), signal);
  } catch (e) {
    if (signal.aborted) throw e;
    return await detailsViaEntities(ids.slice(0, 3), signal);
  }
}

/* --------------------------------- ranking -------------------------------- */

interface Ranked {
  d: OrgDetails;
  score: number;
  org: boolean;
}

function scoreOf(d: OrgDetails, query: string, order: number): { score: number; org: boolean } {
  let orgType = false;
  let negType = false;
  let human = false;
  let disamb = false;
  for (const t of d.types) {
    if (/^human$/i.test(t)) human = true;
    else if (/disambiguation/i.test(t)) disamb = true;
    else if (ORG_RX.test(t)) orgType = true;
    else if (NEG_RX.test(t)) negType = true;
  }
  const descOrg = looksLikeOrg(d.description);
  let s = 0;
  if (orgType) s += 45;
  else if (descOrg) s += 30;
  if (negType && !orgType) s -= 40;
  if (human) s -= 80;
  if (disamb) s -= 150;
  if (d.logos.length || d.icons.length) s += 12;
  if (d.employees) s += 4;
  if (d.industries.length) s += 6;
  if (d.websites.length) s += 3;
  s += Math.log2(1 + d.sitelinks) * 4;
  if (d.countries.some((c) => /united states/i.test(c))) s += 5;
  const ql = normName(query);
  const dl = normName(d.label);
  if (ql && dl === ql) s += 12;
  else if (ql && dl && (dl.startsWith(ql) || ql.startsWith(dl))) s += 6;
  s -= order * 2.5;
  return { score: s, org: (orgType || descOrg) && !human && !disamb };
}

function rank(cands: Candidate[], det: Map<string, OrgDetails>, query: string): Ranked[] {
  return cands
    .map((c, i) => {
      const d = det.get(c.id) ?? { ...blank(c.id), label: c.label, description: c.description };
      if (!d.label || /^Q\d+$/.test(d.label)) d.label = c.label;
      if (!d.description) d.description = c.description;
      return { d, ...scoreOf(d, query, i) };
    })
    .filter((r) => r.d.label && !/^Q\d+$/.test(r.d.label))
    .sort((a, b) => b.score - a.score);
}

/* ------------------------------------ AI ----------------------------------- */

/** Ask a language model which real organization a vague description refers to. Returns null if unsure. */
async function aiIdentify(query: string, signal: AbortSignal): Promise<string | null> {
  const prompt = `Which real company or organization is this: "${query}"? Reply with only its official name, or NONE if it is not a real organization.`;
  const t = withTimeout(signal, 16000);
  try {
    const res = await fetch(AI_TEXT + encodeURIComponent(prompt), { signal: t.signal });
    if (!res.ok) return null;
    const line = (await res.text()).trim().split("\n")[0] ?? "";
    const name = line.replace(/^["'“”*\s]+|["'“”*.\s]+$/g, "").trim();
    if (!name || /^none\b/i.test(name) || name.length > 80) return null;
    return name;
  } catch {
    return null;
  } finally {
    t.done();
  }
}

/* ---------------------------------- logos ---------------------------------- */

function fileScore(n: string): number {
  let s = 0;
  if (/old|former|histor|retired|previous|vintage|defunct/i.test(n)) s += 5;
  if (!/\.svg$/i.test(n)) s += 1;
  const rx = /(^|\D)((?:19|20)\d\d)(?!\d)/g;
  let m: RegExpExecArray | null;
  let maxYear = 0;
  while ((m = rx.exec(n))) maxYear = Math.max(maxYear, Number(m[2]));
  if (maxYear) s -= (maxYear - 1900) / 1000;
  return s;
}

function pickFile(names: string[]): string | null {
  const list = names.filter((n) => /\.(svg|png|jpe?g|gif|webp)$/i.test(n));
  if (!list.length) return null;
  return [...list].sort((a, b) => fileScore(a) - fileScore(b) || a.localeCompare(b))[0];
}

/** Direct upload.wikimedia.org URLs for a Commons file (250px rendition, then the original for small rasters). */
function commonsUrls(name: string): string[] {
  const file = name.replace(/ /g, "_");
  const h = md5(file);
  const enc = encodeURIComponent(file).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());
  const rel = `${h[0]}/${h.slice(0, 2)}/${enc}`;
  if (/\.svg$/i.test(file)) return [`${UPLOAD}thumb/${rel}/250px-${enc}.png`];
  return [`${UPLOAD}thumb/${rel}/250px-${enc}`, `${UPLOAD}${rel}`];
}

async function commonsApiUrl(name: string, signal: AbortSignal): Promise<string | null> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const j: any = await getJson(
    `${COMMONS_API}?action=query&format=json&origin=*&prop=imageinfo&iiprop=url&iiurlwidth=250&titles=${encodeURIComponent("File:" + name)}`,
    signal
  );
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const page: any = Object.values(j.query?.pages ?? {})[0];
  return page?.imageinfo?.[0]?.thumburl ?? page?.imageinfo?.[0]?.url ?? null;
}

const LOGO_NAME_RX = /logo|wordmark|emblem|insignia|seal|symbol|icon|badge|brand|monogram/i;
const PHOTO_RX = /photo|exterior|interior|building|headquarters|\bhq\b|storefront|office|campus|plant|factory|portrait|map|flag|locator|chart|diagram/i;

function titleFromArticle(article: string): string {
  try {
    return decodeURIComponent(article.split("/wiki/")[1] ?? "").replace(/_/g, " ");
  } catch {
    return "";
  }
}

/** The article's lead image — used only when its file name says it's a logo (not a photo of a store). */
async function wikipediaLogo(article: string, signal: AbortSignal): Promise<string | null> {
  const title = titleFromArticle(article);
  if (!title) return null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const j: any = await getJson(
    `https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&prop=pageimages&piprop=thumbnail|name&pithumbsize=250&pilicense=any&redirects=1&titles=${encodeURIComponent(title)}`,
    signal
  );
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const page: any = Object.values(j.query?.pages ?? {})[0];
  const name: string = page?.pageimage ?? "";
  const src: string = page?.thumbnail?.source ?? "";
  if (!name || !src || !LOGO_NAME_RX.test(name) || PHOTO_RX.test(name)) return null;
  return src;
}

async function wikipediaSummary(article: string, signal: AbortSignal): Promise<string> {
  const title = titleFromArticle(article);
  if (!title) return "";
  const j = await getJson<{ extract?: string }>(
    `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, "_"))}`,
    signal,
    9000
  );
  const text = (j.extract ?? "").replace(/\s+/g, " ").trim();
  const sentences = text.match(/[^.!?]+[.!?]+(\s|$)/g) ?? [text];
  let out = "";
  for (const s of sentences) {
    if ((out + s).length > 300 && out) break;
    out += s;
  }
  return out.trim();
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("image failed to decode"));
    img.src = src;
  });
}

/** Downscale the processed logo for local storage (WebP where supported). */
async function compactLogo(url: string, max = 240): Promise<string> {
  const img = await loadImage(url);
  const sc = Math.min(1, max / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.round((img.naturalWidth || 1) * sc));
  c.height = Math.max(1, Math.round((img.naturalHeight || 1) * sc));
  const ctx = c.getContext("2d");
  if (!ctx) return url;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, 0, 0, c.width, c.height);
  const webp = c.toDataURL("image/webp", 0.9);
  return webp.startsWith("data:image/webp") ? webp : c.toDataURL("image/png");
}

interface FoundLogo {
  logo: RealLogo;
  url: string;
  source: string;
}

async function findLogo(d: OrgDetails, signal: AbortSignal): Promise<FoundLogo | null> {
  const tryUrl = async (url: string, minSize = 0): Promise<RealLogo | null> => {
    if (signal.aborted) throw new Error("aborted");
    const data = await fetchAsDataUrl(url);
    if (minSize) {
      const img = await loadImage(data);
      if (Math.max(img.naturalWidth, img.naturalHeight) < minSize) return null;
    }
    return processLogoDataUrl(data);
  };

  const sources: [string[], string][] = [
    [d.logos, "Wikimedia Commons (Wikidata logo)"],
    [d.icons, "Wikimedia Commons (Wikidata icon)"],
  ];
  for (const [names, label] of sources) {
    const name = pickFile(names);
    if (!name) continue;
    for (const url of commonsUrls(name)) {
      try {
        const logo = await tryUrl(url);
        if (logo) return { logo, url, source: label };
      } catch {
        if (signal.aborted) throw new Error("aborted");
      }
    }
    try {
      const url = await commonsApiUrl(name, signal);
      if (url) {
        const logo = await tryUrl(url);
        if (logo) return { logo, url, source: label };
      }
    } catch {
      if (signal.aborted) throw new Error("aborted");
    }
  }

  if (d.article) {
    try {
      const src = await wikipediaLogo(d.article, signal);
      if (src) {
        const logo = await tryUrl(src);
        if (logo) return { logo, url: src, source: "Wikipedia" };
      }
    } catch {
      if (signal.aborted) throw new Error("aborted");
    }
  }

  const site = pickWebsite(d.websites);
  if (site) {
    try {
      const host = new URL(site).hostname.replace(/^www\./, "");
      const url = `https://unavatar.io/${host}?fallback=false`;
      const logo = await tryUrl(url, 96);
      if (logo) return { logo, url, source: "the company website" };
    } catch {
      if (signal.aborted) throw new Error("aborted");
    }
  }
  return null;
}

/** Prefer the main site (patagonia.com) over regional ones (eu.patagonia.com). */
function pickWebsite(urls: string[]): string {
  const host = (u: string) => {
    try {
      return new URL(u).hostname.replace(/^www\./, "");
    } catch {
      return u;
    }
  };
  return [...urls].sort((a, b) => host(a).length - host(b).length || Number(b.startsWith("https")) - Number(a.startsWith("https")))[0] ?? "";
}

/* ------------------------------------ run ---------------------------------- */

export async function researchCompany(
  query: string,
  opts: { qid?: string },
  onStep: (steps: ResearchStep[]) => void,
  signal: AbortSignal
): Promise<ResearchOutcome> {
  const steps: ResearchStep[] = [];
  const emit = () => onStep(steps.map((s) => ({ ...s })));
  const begin = (key: string, label: string) => {
    const s: ResearchStep = { key, label, status: "run" };
    steps.push(s);
    emit();
    return s;
  };
  const end = (s: ResearchStep, status: StepStatus, detail?: string) => {
    s.status = status;
    if (detail) s.detail = detail;
    emit();
  };
  const q = query.trim();

  try {
    // 1 · search
    const s1 = begin("search", `Searching Wikidata for “${q || opts.qid}”`);
    let cands = q ? await gather(q, signal) : [];
    if (opts.qid && !cands.some((c) => c.id === opts.qid)) cands = [{ id: opts.qid, label: q, description: "" }, ...cands];
    end(s1, cands.length ? "ok" : "warn", cands.length ? `${cands.length} possible match${cands.length === 1 ? "" : "es"}` : "Nothing with that name");

    // 2 · compare
    let ranked: Ranked[] = [];
    let best: Ranked | null = null;
    if (cands.length) {
      const s2 = begin("compare", `Comparing ${Math.min(cands.length, 10)} matches`);
      const det = await fetchDetails(cands.map((c) => c.id), signal);
      ranked = rank(cands, det, q);
      best = opts.qid ? ranked.find((r) => r.d.id === opts.qid) ?? null : ranked.find((r) => r.org && r.score > 15) ?? null;
      end(
        s2,
        best ? "ok" : "warn",
        best ? `Best match: ${best.d.label}${best.d.description ? ` — ${best.d.description}` : ""}` : "None of them is a company or organization"
      );
    }

    // 2b · AI interprets vague descriptions — then we verify its answer on Wikidata
    let viaAi: string | null = null;
    if (!best && q) {
      const s3 = begin("ai", `Asking AI which organization “${q}” means`);
      const name = await aiIdentify(q, signal);
      if (name && normName(name) !== normName(q)) {
        const c2 = await gather(name, signal);
        if (c2.length) {
          const r2 = rank(c2, await fetchDetails(c2.map((c) => c.id), signal), name);
          const b2 = r2.find((r) => r.org && r.score > 15) ?? null;
          if (b2) {
            best = b2;
            ranked = r2;
            viaAi = name;
          }
        }
      }
      end(
        s3,
        best ? "ok" : "warn",
        best
          ? `AI suggested “${name}” — verified on Wikidata as ${best.d.label}`
          : name
            ? `AI suggested “${name}”, but it couldn’t be verified`
            : "AI couldn’t identify a real organization"
      );
    }

    if (!best) {
      const s4 = begin("design", "No real organization found");
      end(s4, "warn", `The AI logo studio designs concepts for “${q}” instead`);
      return { kind: "nomatch", query: q };
    }

    // 3 · facts
    const d = best.d;
    const s5 = begin("facts", "Collecting facts");
    const summary = d.article ? await wikipediaSummary(d.article, signal).catch(() => "") : "";
    const facts = [
      d.hq[0],
      d.founded ? `founded ${d.founded}` : "",
      d.employees ? `${formatEmployees(d.employees)} employees` : "",
      d.industries[0] ?? "",
    ].filter(Boolean);
    end(s5, "ok", facts.length ? facts.join(" · ") : "Basic details only");

    // 4 · official logo (or hand off to the designer)
    const s6 = begin("logo", "Looking for the official logo");
    const found = await findLogo(d, signal);
    end(s6, found ? "ok" : "warn", found ? `Found on ${found.source}` : "No official logo is published in open sources");
    let logoData: string | null = null;
    if (found) {
      try {
        logoData = await compactLogo(found.logo.url);
      } catch {
        logoData = found.logo.url;
      }
    } else {
      const s7 = begin("design", "Designing a logo");
      end(s7, "ok", "Logo concepts are ready in the AI logo studio below");
    }

    const org: ResearchedOrg = {
      id: `wd:${d.id}`,
      qid: d.id,
      name: d.label,
      officialName: d.officialName && d.officialName !== d.label ? d.officialName : "",
      description: d.description,
      industry: industryFrom(d),
      industryLabel: d.industries[0] ?? "",
      hq: d.hq[0] ?? "",
      country: d.countries[0] ?? "",
      website: pickWebsite(d.websites),
      founded: d.founded,
      employees: d.employees,
      summary,
      article: d.article ?? "",
      logoUrl: found?.url ?? null,
      logoSource: found?.source ?? null,
      logoData,
      logoAspect: found?.logo.aspect ?? 1,
      logoDark: found?.logo.dark ?? false,
      logoBrand: found?.logo.brand ?? null,
      query: q,
      viaAi,
      researchedAt: Date.now(),
    };
    const alternatives = ranked
      .filter((r) => r !== best && r.org && r.score > 0)
      .slice(0, 4)
      .map((r) => ({ id: r.d.id, label: r.d.label, description: r.d.description }));
    return { kind: "found", org, alternatives, viaAi };
  } catch {
    if (signal.aborted) return { kind: "aborted" };
    const running = steps.find((x) => x.status === "run");
    if (running) end(running, "fail", "Network error");
    return { kind: "error", message: "Couldn’t reach Wikidata — check your connection and try again" };
  }
}
