import { useCallback, useRef, useState } from "react";
import { researchCompany, type Candidate, type ResearchOutcome, type ResearchStep, type ResearchedOrg } from "./research";

export interface ResearchState {
  status: "idle" | "running" | "done" | "nomatch" | "error";
  query: string;
  steps: ResearchStep[];
  result: ResearchedOrg | null;
  alternatives: Candidate[];
  viaAi: string | null;
  error: string;
}

const IDLE: ResearchState = { status: "idle", query: "", steps: [], result: null, alternatives: [], viaAi: null, error: "" };

/** Runs one research at a time (a new one cancels the previous) and exposes the live step log. */
export function useResearch() {
  const [state, setState] = useState<ResearchState>(IDLE);
  const ctl = useRef<AbortController | null>(null);

  const run = useCallback(async (query: string, qid?: string): Promise<ResearchOutcome> => {
    ctl.current?.abort();
    const ac = new AbortController();
    ctl.current = ac;
    setState({ ...IDLE, status: "running", query });
    const out = await researchCompany(
      query,
      { qid },
      (steps) => {
        if (!ac.signal.aborted) setState((s) => ({ ...s, steps }));
      },
      ac.signal
    );
    if (ac.signal.aborted || out.kind === "aborted") return { kind: "aborted" };
    if (out.kind === "found") setState((s) => ({ ...s, status: "done", result: out.org, alternatives: out.alternatives, viaAi: out.viaAi }));
    else if (out.kind === "nomatch") setState((s) => ({ ...s, status: "nomatch" }));
    else setState((s) => ({ ...s, status: "error", error: out.message }));
    return out;
  }, []);

  const reset = useCallback(() => {
    ctl.current?.abort();
    setState(IDLE);
  }, []);

  return { state, run, reset };
}
