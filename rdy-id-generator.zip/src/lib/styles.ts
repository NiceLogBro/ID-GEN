/**
 * Card styles = a layout (4 of them) + a generated palette + a background pattern + corner radius.
 * Set 0 is a hand-tuned set; every "refresh" (seed > 0) deterministically generates a brand-new set of 4.
 */

export type LayoutId = "classic" | "banner" | "modern" | "campus";
export type PatternId = "dots" | "lines" | "grid" | "cross" | "none";

export interface Palette {
  name: string;
  dark: boolean;
  bg: string;
  bg2: string;
  accent: string;
  accent2: string;
  /** readable text/ink drawn on top of the accent */
  onAccent: string;
  accentSoft: string;
  accentText: string;
  text: string;
  subtext: string;
  /** the ID "label plate" */
  plate: string;
  plateText: string;
  plateSub: string;
  patternColor: string;
  slot: string;
}

export interface CardStyle {
  id: string;
  layout: LayoutId;
  palette: Palette;
  pattern: PatternId;
  radius: number;
}

export const LAYOUT_ORDER: LayoutId[] = ["classic", "banner", "modern", "campus"];

export const LAYOUT_META: Record<LayoutId, { name: string; blurb: string }> = {
  classic: { name: "Classic", blurb: "Centered photo & ID plate" },
  banner: { name: "Banner", blurb: "Color header, photo overlaps" },
  modern: { name: "Modern", blurb: "Big photo, bold type" },
  campus: { name: "Campus", blurb: "Vintage stripes & seal" },
};

/* ------------------------------ color helpers ------------------------------ */

function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  h = ((h % 360) + 360) % 360;
  s /= 100;
  l /= 100;
  const k = (n: number) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
}
const hex = (h: number, s: number, l: number) =>
  "#" +
  hslToRgb(h, s, l)
    .map((v) => v.toString(16).padStart(2, "0"))
    .join("");
const rgba = (h: number, s: number, l: number, a: number) => {
  const [r, g, b] = hslToRgb(h, s, l);
  return `rgba(${r},${g},${b},${a})`;
};

function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------ curated set 0 ------------------------------ */

const GRAPHITE: Palette = {
  name: "Graphite",
  dark: true,
  bg: "#232936",
  bg2: "#181d27",
  accent: "#ff8a3d",
  accent2: "#ffb347",
  onAccent: "#1a1208",
  accentSoft: "rgba(255,138,61,0.16)",
  accentText: "#ffb07a",
  text: "#f4f5f7",
  subtext: "#a6aebc",
  plate: "#f4f5f7",
  plateText: "#181d27",
  plateSub: "#566070",
  patternColor: "rgba(244,245,247,0.07)",
  slot: "rgba(0,0,0,0.45)",
};

const PAPER: Palette = {
  name: "Paper",
  dark: false,
  bg: "#f2efe7",
  bg2: "#e5e1d4",
  accent: "#d9531e",
  accent2: "#f08a3c",
  onAccent: "#ffffff",
  accentSoft: "rgba(224,90,31,0.12)",
  accentText: "#b8430f",
  text: "#1c2027",
  subtext: "#6d7480",
  plate: "#1c2027",
  plateText: "#f4f5f7",
  plateSub: "#9aa3b1",
  patternColor: "rgba(28,32,39,0.06)",
  slot: "rgba(28,32,39,0.35)",
};

const MOSS: Palette = {
  name: "Moss",
  dark: true,
  bg: "#143830",
  bg2: "#0d271f",
  accent: "#8fe3b0",
  accent2: "#5fcf93",
  onAccent: "#0d271f",
  accentSoft: "rgba(143,227,176,0.14)",
  accentText: "#aef0c8",
  text: "#f2f7f3",
  subtext: "#9fc2ad",
  plate: "#f2f7f3",
  plateText: "#0d271f",
  plateSub: "#4f7562",
  patternColor: "rgba(242,247,243,0.07)",
  slot: "rgba(0,0,0,0.45)",
};

const COLLEGIATE: Palette = {
  name: "Collegiate",
  dark: false,
  bg: "#f6f0e1",
  bg2: "#eadfc6",
  accent: "#7a1f2b",
  accent2: "#c9972f",
  onAccent: "#fff8e8",
  accentSoft: "rgba(122,31,43,0.10)",
  accentText: "#7a1f2b",
  text: "#2a1a1c",
  subtext: "#7b6a62",
  plate: "#2a1a1c",
  plateText: "#f6f0e1",
  plateSub: "#b9a999",
  patternColor: "rgba(122,31,43,0.06)",
  slot: "rgba(42,26,28,0.3)",
};

const CURATED: CardStyle[] = [
  { id: "0-0", layout: "classic", palette: GRAPHITE, pattern: "dots", radius: 24 },
  { id: "0-1", layout: "banner", palette: PAPER, pattern: "none", radius: 24 },
  { id: "0-2", layout: "modern", palette: MOSS, pattern: "grid", radius: 24 },
  { id: "0-3", layout: "campus", palette: COLLEGIATE, pattern: "cross", radius: 20 },
];

/* ---------------------------- generated palettes ---------------------------- */

const HUE_NAMES = ["Ruby", "Ember", "Amber", "Lime", "Moss", "Jade", "Lagoon", "Azure", "Cobalt", "Indigo", "Orchid", "Rose"];
const PATTERNS: PatternId[] = ["dots", "lines", "grid", "cross", "none"];
const RADII = [16, 22, 28];

function generatePalette(rng: () => number, hue?: number): Palette {
  const roll = rng();
  const mode: "dark" | "light" | "vivid" = roll < 0.4 ? "dark" : roll < 0.73 ? "light" : "vivid";
  const h = Math.floor(hue ?? rng() * 360);
  const shifts = [25, 40, 150, 180, 210];
  const h2 = h + shifts[Math.floor(rng() * shifts.length)] * (rng() < 0.5 ? 1 : -1);
  const sat = rng() * 10;
  const name = `${HUE_NAMES[Math.floor(((h + 15) % 360) / 30)]} ${mode === "dark" ? "Night" : mode === "light" ? "Paper" : "Pop"}`;

  if (mode === "dark") {
    return {
      name,
      dark: true,
      bg: hex(h, 32 + sat, 17),
      bg2: hex(h, 38 + sat, 9.5),
      accent: hex(h2, 88, 62),
      accent2: hex(h2 + 28, 90, 58),
      onAccent: hex(h, 50, 9),
      accentSoft: rgba(h2, 88, 62, 0.16),
      accentText: hex(h2, 90, 76),
      text: hex(h, 25, 96),
      subtext: hex(h, 14, 70),
      plate: hex(h, 22, 95),
      plateText: hex(h, 40, 12),
      plateSub: hex(h, 15, 40),
      patternColor: rgba(h, 30, 96, 0.07),
      slot: "rgba(0,0,0,0.45)",
    };
  }
  if (mode === "light") {
    return {
      name,
      dark: false,
      bg: hex(h, 36, 94),
      bg2: hex(h, 32, 87),
      accent: hex(h2, 72, 40),
      accent2: hex(h2 + 28, 78, 52),
      onAccent: "#ffffff",
      accentSoft: rgba(h2, 72, 40, 0.12),
      accentText: hex(h2, 75, 33),
      text: hex(h, 35, 12),
      subtext: hex(h, 12, 42),
      plate: hex(h, 32, 14),
      plateText: hex(h, 25, 96),
      plateSub: hex(h, 14, 68),
      patternColor: rgba(h, 40, 12, 0.06),
      slot: rgba(h, 40, 12, 0.3),
    };
  }
  return {
    name,
    dark: true,
    bg: hex(h, 62 + sat, 36),
    bg2: hex(h, 70 + sat, 24),
    accent: hex(h2, 95, 68),
    accent2: hex(h2 + 30, 92, 62),
    onAccent: hex(h, 65, 12),
    accentSoft: rgba(h2, 95, 68, 0.18),
    accentText: hex(h2, 95, 80),
    text: hex(h, 30, 98),
    subtext: hex(h, 45, 84),
    plate: hex(h, 40, 97),
    plateText: hex(h, 65, 14),
    plateSub: hex(h, 25, 40),
    patternColor: "rgba(255,255,255,0.09)",
    slot: "rgba(0,0,0,0.35)",
  };
}

/* ------------------------- custom color overrides ------------------------- */

export function hexToRgb(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  let h = m[1];
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  if (max === min) return [0, 0, l * 100];
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  let h = 0;
  if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
  else if (max === g) h = ((b - r) / d + 2) / 6;
  else h = ((r - g) / d + 4) / 6;
  return [h * 360, s * 100, l * 100];
}

function hslToHex(h: number, s: number, l: number): string {
  return hex(h, Math.max(0, Math.min(100, s)), Math.max(0, Math.min(100, l)));
}

/** relative luminance 0..1 */
export function luminance(hexColor: string): number {
  const rgb = hexToRgb(hexColor) ?? [20, 20, 20];
  const [r, g, b] = rgb.map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** blend two hex colors; t=0 → a, t=1 → b */
export function mix(a: string, b: string, t: number): string {
  const ra = hexToRgb(a) ?? [0, 0, 0];
  const rb = hexToRgb(b) ?? [255, 255, 255];
  const c = ra.map((v, i) => Math.round(v + (rb[i] - v) * t));
  return "#" + c.map((v) => Math.max(0, Math.min(255, v)).toString(16).padStart(2, "0")).join("");
}

/** shift lightness by dl points (-100..100) */
export function shade(hexColor: string, dl: number): string {
  const rgb = hexToRgb(hexColor) ?? [128, 128, 128];
  const [h, s, l] = rgbToHsl(rgb[0], rgb[1], rgb[2]);
  return hslToHex(h, s, l + dl);
}

export function withAlpha(hexColor: string, a: number): string {
  const [r, g, b] = hexToRgb(hexColor) ?? [0, 0, 0];
  return `rgba(${r},${g},${b},${a})`;
}

/** readable ink (white or near-black) on top of the given color */
export function contrastInk(hexColor: string): string {
  return luminance(hexColor) > 0.45 ? "#15181d" : "#ffffff";
}

export function isHexColor(v: string): boolean {
  return /^#[0-9a-f]{6}$/i.test(v.trim());
}

export function normalizeHex(v: string, fallback: string): string {
  const t = v.trim();
  if (/^#[0-9a-f]{6}$/i.test(t)) return t.toLowerCase();
  const m = /^#?([0-9a-f]{3})$/i.exec(t);
  if (m) return ("#" + m[1].split("").map((c) => c + c).join("")).toLowerCase();
  const full = /^#?([0-9a-f]{6})$/i.exec(t);
  if (full) return ("#" + full[1]).toLowerCase();
  return fallback;
}

export interface CustomColorSet {
  bg: string;
  accent: string;
  text: string;
  plate: string;
}

/**
 * Rebuild a full palette from 4 user colors, keeping the layout's structure.
 * Everything else (gradient, soft tints, muted text, ID plate ink…) is derived
 * so the card always stays readable no matter what you pick.
 */
export function applyCustomColors(base: Palette, c: CustomColorSet): Palette {
  const bg = normalizeHex(c.bg, base.bg);
  const accent = normalizeHex(c.accent, base.accent);
  const text = normalizeHex(c.text, base.text);
  const plate = normalizeHex(c.plate, base.plate);
  const dark = luminance(bg) < 0.4;
  const accentDark = luminance(accent) < 0.35;
  return {
    name: "Custom",
    dark,
    bg,
    bg2: shade(bg, dark ? -7 : -6),
    accent,
    accent2: shade(accent, accentDark ? 14 : -12),
    onAccent: contrastInk(accent),
    accentSoft: withAlpha(accent, 0.16),
    accentText: dark ? mix(accent, "#ffffff", 0.3) : shade(accent, -16),
    text,
    subtext: mix(text, bg, 0.38),
    plate,
    plateText: contrastInk(plate),
    plateSub: mix(contrastInk(plate), plate, 0.45),
    patternColor: withAlpha(text, dark ? 0.08 : 0.07),
    slot: dark ? "rgba(0,0,0,0.45)" : withAlpha(text, 0.3),
  };
}

/** Card colors built around one brand color: deep brand-tinted card, brand accent, light ink. */
export function brandToCustom(brand: string): CustomColorSet {
  const b = normalizeHex(brand, "#2563eb");
  if (luminance(b) < 0.06) return { bg: b, accent: mix(b, "#ffffff", 0.62), text: "#f4f5f7", plate: "#f4f5f7" };
  return { bg: mix(b, "#0a0c10", 0.8), accent: b, text: "#f4f5f7", plate: "#f4f5f7" };
}

/** one-tap starting points for the custom color editor */
export const CUSTOM_PRESETS: { name: string; bg: string; accent: string; text: string; plate: string }[] = [
  { name: "Midnight", bg: "#1b2340", accent: "#7dd3fc", text: "#eef2ff", plate: "#eef2ff" },
  { name: "Crimson", bg: "#4c0519", accent: "#fbbf24", text: "#fff1f2", plate: "#fff7ed" },
  { name: "Forest", bg: "#0f2e23", accent: "#a3e635", text: "#ecfdf5", plate: "#ecfdf5" },
  { name: "Ocean", bg: "#0c2d48", accent: "#38bdf8", text: "#f0f9ff", plate: "#f0f9ff" },
  { name: "Royal", bg: "#2e1065", accent: "#c084fc", text: "#faf5ff", plate: "#faf5ff" },
  { name: "Ember", bg: "#221206", accent: "#fb923c", text: "#fff7ed", plate: "#fff7ed" },
  { name: "Sand", bg: "#ece2d0", accent: "#b45309", text: "#292019", plate: "#292019" },
  { name: "Mono", bg: "#101216", accent: "#e7eaef", text: "#f4f5f7", plate: "#f4f5f7" },
];

/** Deterministic: the same seed always returns the same 4 styles. */
export function getStyles(seed: number): CardStyle[] {
  if (seed <= 0) return CURATED;
  const rng = mulberry32(seed * 7919 + 101);
  const order = [...LAYOUT_ORDER];
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  // Space the four base hues ~90° apart so every set is visibly varied (no duplicate palettes).
  const h0 = rng() * 360;
  return order.map((layout, i) => ({
    id: `${seed}-${i}`,
    layout,
    palette: generatePalette(rng, (h0 + i * 90 + rng() * 30) % 360),
    pattern: PATTERNS[Math.floor(rng() * PATTERNS.length)],
    radius: RADII[Math.floor(rng() * RADII.length)],
  }));
}
