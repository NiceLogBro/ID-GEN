import { useSyncExternalStore } from "react";
import type { ResearchedOrg } from "./research";
import { fetchAsDataUrl, processLogoDataUrl, type RealResult } from "./logos";
import { isIndustry } from "./industries";

/** Companies found by the research assistant — kept in localStorage so they join the directory for good. */
const KEY = "badgesmith:research:v1";
const MAX = 20;

function valid(o: unknown): o is ResearchedOrg {
  const r = o as ResearchedOrg;
  return !!r && typeof r.id === "string" && r.id.startsWith("wd:") && typeof r.name === "string" && r.name.length > 0;
}

function load(): ResearchedOrg[] {
  try {
    const raw = localStorage.getItem(KEY);
    const arr: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(arr)) return [];
    return arr.filter(valid).map((r) => ({ ...r, industry: isIndustry(r.industry) ? r.industry : "general" }));
  } catch {
    return [];
  }
}

let list: ResearchedOrg[] = typeof localStorage === "undefined" ? [] : load();
const subs = new Set<() => void>();

function persist() {
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
    return;
  } catch {
    /* over quota — drop cached logo images from the oldest entries until it fits */
  }
  for (let i = list.length - 1; i >= 0; i--) {
    if (!list[i].logoData) continue;
    list = list.map((o, j) => (j === i ? { ...o, logoData: null } : o));
    try {
      localStorage.setItem(KEY, JSON.stringify(list));
      return;
    } catch {
      /* keep trimming */
    }
  }
}

function emit() {
  subs.forEach((fn) => fn());
}

export function getResearched(): ResearchedOrg[] {
  return list;
}

export function findResearched(id: string): ResearchedOrg | null {
  return list.find((r) => r.id === id) ?? null;
}

export function upsertResearched(org: ResearchedOrg) {
  list = [org, ...list.filter((o) => o.id !== org.id)].slice(0, MAX);
  persist();
  emit();
}

export function clearResearched() {
  list = [];
  persist();
  emit();
}

export function useResearchedList(): ResearchedOrg[] {
  return useSyncExternalStore(
    (fn) => {
      subs.add(fn);
      return () => subs.delete(fn);
    },
    getResearched,
    getResearched
  );
}

/** The researched company's logo: the cached copy, or re-fetched from its source if the cache was dropped. */
export async function loadResearchedLogo(id: string): Promise<RealResult> {
  const r = findResearched(id);
  if (!r) return { status: "none" };
  if (r.logoData) {
    return { status: "found", logo: { url: r.logoData, aspect: r.logoAspect || 1, dark: !!r.logoDark, brand: r.logoBrand ?? null } };
  }
  if (!r.logoUrl) return { status: "none" };
  try {
    const logo = await processLogoDataUrl(await fetchAsDataUrl(r.logoUrl));
    list = list.map((o) => (o.id === id ? { ...o, logoData: logo.url, logoAspect: logo.aspect, logoDark: logo.dark, logoBrand: logo.brand } : o));
    persist();
    emit();
    return { status: "found", logo };
  } catch {
    return { status: "error" };
  }
}
