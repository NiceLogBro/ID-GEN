import { AI_MARKS, type AiMark } from "../data/aiMarks";
import type { IndustryId } from "../types";
import { contrastInk, luminance, shade } from "./styles";

/**
 * Logo concepts for any organization, rendered in the browser on a canvas.
 * Most concepts are built around one of 18 marks drawn by an image model (vectorized),
 * picked to suit the industry; the monogram is purely typographic.
 */
export interface LogoConcept {
  key: string;
  /** "ai" = built around a mark drawn by an image model · "auto" = typographic, designed in the browser */
  kind: "ai" | "auto";
  label: string;
  src: string;
  fit: "cover" | "contain";
  aspect: number;
  dark: boolean;
}

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(arr: T[], rng: () => number): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const SUFFIX = /\b(incorporated|inc|corporation|corp|company|co|holdings?|group|plc|ltd|llc|l\.?p|the)\b\.?/gi;

/** "Apple Inc." → "Apple", "The Home Depot" → "Home Depot" */
export function shortOrgName(name: string): string {
  const s = name
    .replace(/\(.*?\)/g, " ")
    .replace(/,/g, " ")
    .replace(SUFFIX, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/[\s&-]+$/, "");
  return s || name.trim() || "Organization";
}

const STOP = new Set(["and", "of", "the", "for", "a", "an", "de"]);

export function orgInitials(name: string): string {
  const words = shortOrgName(name)
    .replace(/[^\p{L}\p{N}\s-]/gu, " ")
    .split(/[\s-]+/)
    .filter(Boolean);
  const sig = words.filter((w) => !STOP.has(w.toLowerCase()));
  const base = sig.length ? sig : words;
  if (!base.length) return "O";
  if (base.length === 1) return Array.from(base[0])[0].toUpperCase();
  return base
    .slice(0, 2)
    .map((w) => Array.from(w)[0])
    .join("")
    .toUpperCase();
}

const AUTO_BRANDS = ["#2563eb", "#dc2626", "#059669", "#d97706", "#7c3aed", "#0891b2", "#db2777", "#ea580c", "#0f766e", "#1d4ed8", "#9333ea", "#be123c"];

/** A stable, brand-like color for an organization without a known logo. */
export function autoBrandColor(name: string): string {
  return AUTO_BRANDS[hash(name.trim().toLowerCase()) % AUTO_BRANDS.length];
}

/* ---------------------------------- type ---------------------------------- */

interface FontSpec {
  name: string;
  weight: number;
  family: string;
  upper: boolean;
  track: number;
}

const FONTS: FontSpec[] = [
  { name: "geometric", weight: 700, family: '"Space Grotesk", Manrope, Arial, sans-serif', upper: false, track: 0 },
  { name: "bold sans", weight: 800, family: "Manrope, Arial, sans-serif", upper: false, track: 0 },
  { name: "serif", weight: 700, family: 'Georgia, "Times New Roman", serif', upper: false, track: 0 },
  { name: "spaced caps", weight: 600, family: "Manrope, Arial, sans-serif", upper: true, track: 0.14 },
];

const font = (f: FontSpec, size: number) => `${f.weight} ${size}px ${f.family}`;

function measure(ctx: CanvasRenderingContext2D, text: string, f: FontSpec, size: number): number {
  ctx.font = font(f, size);
  if (!f.track) return ctx.measureText(text).width;
  const chars = Array.from(text);
  let w = 0;
  for (const ch of chars) w += ctx.measureText(ch).width;
  return w + f.track * size * Math.max(0, chars.length - 1);
}

function draw(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, f: FontSpec, size: number) {
  ctx.font = font(f, size);
  if (!f.track) {
    ctx.fillText(text, x, y);
    return;
  }
  let cx = x;
  for (const ch of Array.from(text)) {
    ctx.fillText(ch, cx, y);
    cx += ctx.measureText(ch).width + f.track * size;
  }
}

/* --------------------------------- shapes --------------------------------- */

type ShapeKind = "circle" | "squircle" | "hexagon" | "diamond";
const SHAPES: ShapeKind[] = ["circle", "squircle", "hexagon", "diamond"];
const SHAPE_NAME: Record<ShapeKind, string> = { circle: "circle", squircle: "rounded square", hexagon: "hexagon", diamond: "diamond" };

function roundedRect(p: Path2D, x: number, y: number, w: number, h: number, r: number) {
  p.moveTo(x + r, y);
  p.arcTo(x + w, y, x + w, y + h, r);
  p.arcTo(x + w, y + h, x, y + h, r);
  p.arcTo(x, y + h, x, y, r);
  p.arcTo(x, y, x + w, y, r);
  p.closePath();
}

function shapePath(kind: ShapeKind, cx: number, cy: number, r: number): Path2D {
  const p = new Path2D();
  if (kind === "circle") {
    p.arc(cx, cy, r, 0, Math.PI * 2);
  } else if (kind === "squircle") {
    roundedRect(p, cx - r, cy - r, r * 2, r * 2, r * 0.42);
  } else if (kind === "hexagon") {
    for (let i = 0; i < 6; i++) {
      const a = (Math.PI / 3) * i - Math.PI / 2;
      const x = cx + r * Math.cos(a);
      const y = cy + r * Math.sin(a);
      if (i === 0) p.moveTo(x, y);
      else p.lineTo(x, y);
    }
    p.closePath();
  } else {
    const rr = r * 1.08;
    p.moveTo(cx, cy - rr);
    p.lineTo(cx + rr, cy);
    p.lineTo(cx, cy + rr);
    p.lineTo(cx - rr, cy);
    p.closePath();
  }
  return p;
}

const pathCache = new Map<string, Path2D>();
function drawMark(ctx: CanvasRenderingContext2D, m: AiMark, x: number, y: number, size: number, color: string) {
  let p = pathCache.get(m.id);
  if (!p) {
    p = new Path2D(m.d);
    pathCache.set(m.id, p);
  }
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(size / 400, size / 400);
  ctx.fillStyle = color;
  ctx.fill(p, "evenodd");
  ctx.restore();
}

const INK = "#15181d";

function newCanvas(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.ceil(w));
  c.height = Math.max(1, Math.ceil(h));
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");
  ctx.textBaseline = "alphabetic";
  return { c, ctx };
}

interface Rendered {
  c: HTMLCanvasElement;
  fit: "cover" | "contain";
  aspect: number;
}

/* -------------------------------- concepts -------------------------------- */

function renderTile(mark: AiMark, brand: string): Rendered {
  const S = 512;
  const { c, ctx } = newCanvas(S, S);
  const p = new Path2D();
  roundedRect(p, 0, 0, S, S, S * 0.22);
  const g = ctx.createLinearGradient(0, 0, S, S);
  g.addColorStop(0, shade(brand, 7));
  g.addColorStop(1, shade(brand, -9));
  ctx.fillStyle = g;
  ctx.fill(p);
  drawMark(ctx, mark, S * 0.17, S * 0.17, S * 0.66, contrastInk(brand));
  return { c, fit: "cover", aspect: 1 };
}

function fitText(ctx: CanvasRenderingContext2D, name: string, f: FontSpec, size0: number, minSize: number, room: number) {
  let text = shortOrgName(name);
  if (f.upper) text = text.toUpperCase();
  let size = size0;
  let tw = measure(ctx, text, f, size);
  if (tw > room) {
    size = Math.max(minSize, (size * room) / tw);
    tw = measure(ctx, text, f, size);
  }
  if (tw > room) {
    const words = text.split(" ");
    let t = words[0];
    for (let i = 1; i < words.length; i++) {
      const nt = `${t} ${words[i]}`;
      if (measure(ctx, nt, f, size) > room) break;
      t = nt;
    }
    text = t;
    tw = measure(ctx, text, f, size);
  }
  return { text, size, tw };
}

function renderWordmark(name: string, mark: AiMark, brand: string, f: FontSpec): Rendered {
  const H = 200;
  const pad = 18;
  const markS = 150;
  const gap = 24;
  const probe = newCanvas(4, 4).ctx;
  const { text, size, tw } = fitText(probe, name, f, 92, 50, H * 3.5 - pad * 2 - markS - gap);
  const W = pad + markS + gap + tw + pad;
  const { c, ctx } = newCanvas(W, H);
  drawMark(ctx, mark, pad - markS * 0.06, (H - markS) / 2, markS, luminance(brand) > 0.55 ? shade(brand, -28) : brand);
  ctx.fillStyle = INK;
  draw(ctx, text, pad + markS + gap, H / 2 + size * 0.35, f, size);
  return { c, fit: "contain", aspect: c.width / c.height };
}

function renderMonogram(name: string, brand: string, f: FontSpec, shape: ShapeKind, filled: boolean): Rendered {
  const S = 512;
  const { c, ctx } = newCanvas(S, S);
  const ink = contrastInk(brand);
  if (filled) {
    ctx.fillStyle = brand;
    ctx.fillRect(0, 0, S, S);
    ctx.strokeStyle = ink;
    ctx.lineWidth = S * 0.022;
    ctx.stroke(shapePath(shape, S / 2, S / 2, S * 0.4));
  } else {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, S, S);
    ctx.fillStyle = brand;
    ctx.fill(shapePath(shape, S / 2, S / 2, S * 0.42));
  }
  const ini = orgInitials(name);
  const fm: FontSpec = { ...f, track: Math.min(f.track, 0.04) };
  let size = (ini.length > 1 ? S * 0.34 : S * 0.44) * (shape === "diamond" ? 0.82 : 1);
  let tw = measure(ctx, ini, fm, size);
  const maxTw = S * (shape === "diamond" ? 0.42 : 0.56);
  if (tw > maxTw) {
    size *= maxTw / tw;
    tw = measure(ctx, ini, fm, size);
  }
  ctx.fillStyle = ink;
  draw(ctx, ini, (S - tw) / 2, S / 2 + size * 0.35, fm, size);
  return { c, fit: "cover", aspect: 1 };
}

function arcText(ctx: CanvasRenderingContext2D, text: string, cx: number, cy: number, r: number, size0: number, color: string, f: FontSpec) {
  const fm: FontSpec = { ...f, weight: Math.max(600, f.weight), track: 0.12 };
  let chars = Array.from(text);
  const span = (sz: number) => {
    ctx.font = font(fm, sz);
    let w = 0;
    for (const ch of chars) w += ctx.measureText(ch).width + fm.track * sz;
    return (w - fm.track * sz) / r;
  };
  const maxSpan = Math.PI * 0.95;
  let size = size0;
  if (span(size) > maxSpan) size = Math.max(size0 * 0.62, (size * maxSpan) / span(size));
  if (span(size) > maxSpan) {
    const words = text.split(" ");
    let t = words[0];
    for (const w of words.slice(1)) {
      chars = Array.from(`${t} ${w}`);
      if (span(size) > maxSpan) break;
      t = `${t} ${w}`;
    }
    chars = Array.from(t);
  }
  ctx.font = font(fm, size);
  ctx.fillStyle = color;
  ctx.textBaseline = "middle";
  let a = -Math.PI / 2 - span(size) / 2;
  ctx.font = font(fm, size);
  for (const ch of chars) {
    const w = ctx.measureText(ch).width;
    const mid = a + w / 2 / r;
    ctx.save();
    ctx.translate(cx + Math.cos(mid) * r, cy + Math.sin(mid) * r);
    ctx.rotate(mid + Math.PI / 2);
    ctx.fillText(ch, -w / 2, 0);
    ctx.restore();
    a += (w + fm.track * size) / r;
  }
  ctx.textBaseline = "alphabetic";
}

function renderSeal(name: string, mark: AiMark, brand: string, f: FontSpec): Rendered {
  const S = 512;
  const cx = S / 2;
  const cy = S / 2;
  const { c, ctx } = newCanvas(S, S);
  const ink = contrastInk(brand);
  ctx.fillStyle = brand;
  ctx.beginPath();
  ctx.arc(cx, cy, S * 0.48, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = ink;
  ctx.lineWidth = S * 0.012;
  ctx.beginPath();
  ctx.arc(cx, cy, S * 0.445, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = ink;
  ctx.beginPath();
  ctx.arc(cx, cy, S * 0.3, 0, Math.PI * 2);
  ctx.fill();
  drawMark(ctx, mark, cx - S * 0.2, cy - S * 0.2, S * 0.4, brand);
  arcText(ctx, shortOrgName(name).toUpperCase(), cx, cy, S * 0.375, S * 0.068, ink, f);
  ctx.fillStyle = ink;
  for (const off of [-0.22, 0, 0.22]) {
    const ang = Math.PI / 2 + off;
    ctx.beginPath();
    ctx.arc(cx + Math.cos(ang) * S * 0.375, cy + Math.sin(ang) * S * 0.375, S * 0.012, 0, Math.PI * 2);
    ctx.fill();
  }
  return { c, fit: "cover", aspect: 1 };
}

function renderStacked(name: string, mark: AiMark, brand: string, f: FontSpec): Rendered {
  const S = 512;
  const { c, ctx } = newCanvas(S, S);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, S, S);
  drawMark(ctx, mark, S * 0.26, S * 0.07, S * 0.48, luminance(brand) > 0.55 ? shade(brand, -28) : brand);
  const { text, size, tw } = fitText(ctx, name, f, S * 0.13, S * 0.07, S * 0.86);
  ctx.fillStyle = INK;
  draw(ctx, text, (S - tw) / 2, S * 0.8, f, size);
  return { c, fit: "cover", aspect: 1 };
}

/* -------------------------------- generator -------------------------------- */

type Kind = "tile" | "wordmark" | "monogram" | "seal" | "stacked";
const KIND_SETS: Kind[][] = [
  ["tile", "wordmark", "monogram", "seal"],
  ["stacked", "tile", "seal", "wordmark"],
  ["wordmark", "monogram", "stacked", "tile"],
  ["seal", "stacked", "wordmark", "monogram"],
];

function markPool(name: string, industry: IndustryId): AiMark[] {
  const rng = mulberry32(hash(`marks|${name}|${industry}`));
  const tagged = AI_MARKS.filter((m) => m.tags.includes(industry));
  const rest = AI_MARKS.filter((m) => !m.tags.includes(industry));
  return [...shuffle(tagged, rng), ...shuffle(rest, rng)];
}

const cache = new Map<string, LogoConcept[]>();

/** Call after web fonts finish loading so concepts re-render with the real typefaces. */
export function clearConceptCache() {
  cache.clear();
}

/** 4 logo concepts for an organization; every seed gives a different, reproducible set. */
export function generateConcepts(name: string, industry: IndustryId, brand: string, seed: number): LogoConcept[] {
  const nm = name.trim() || "Your Company";
  const key = `${nm}|${industry}|${brand}|${seed}`;
  const hit = cache.get(key);
  if (hit) return hit;
  if (typeof document === "undefined") return [];

  const rng = mulberry32(hash(key));
  const pool = markPool(nm, industry);
  const kinds: Kind[] = pool.length ? KIND_SETS[seed % KIND_SETS.length] : ["monogram", "monogram", "monogram", "monogram"];
  const fontStart = Math.floor(rng() * FONTS.length);
  const out: LogoConcept[] = [];

  kinds.forEach((k, i) => {
    const f = FONTS[(fontStart + i) % FONTS.length];
    const mark = pool.length ? pool[(seed * 3 + i) % pool.length] : null;
    try {
      let r: Rendered;
      let label: string;
      let kind: LogoConcept["kind"] = "ai";
      if (k === "monogram" || !mark) {
        const shape = SHAPES[(Math.floor(rng() * SHAPES.length) + i) % SHAPES.length];
        r = renderMonogram(nm, brand, f, shape, rng() < 0.45);
        label = `Monogram · ${SHAPE_NAME[shape]}, ${f.name} type`;
        kind = "auto";
      } else if (k === "tile") {
        r = renderTile(mark, brand);
        label = `Symbol tile · ${mark.name.toLowerCase()} mark`;
      } else if (k === "wordmark") {
        r = renderWordmark(nm, mark, brand, f);
        label = `Wordmark · ${mark.name.toLowerCase()} mark + ${f.name} type`;
      } else if (k === "seal") {
        r = renderSeal(nm, mark, brand, f);
        label = `Seal · ${mark.name.toLowerCase()} mark`;
      } else {
        r = renderStacked(nm, mark, brand, f);
        label = `Stacked · ${mark.name.toLowerCase()} mark + ${f.name} type`;
      }
      out.push({ key: `${seed}-${i}-${k}`, kind, label, src: r.c.toDataURL("image/png"), fit: r.fit, aspect: r.aspect, dark: false });
    } catch {
      /* skip a concept that failed to render */
    }
  });

  if (cache.size > 60) cache.clear();
  cache.set(key, out);
  return out;
}
